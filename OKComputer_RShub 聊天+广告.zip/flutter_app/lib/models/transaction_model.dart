import 'package:cloud_firestore/cloud_firestore.dart';

class TransactionModel {
  final String transactionId;
  final String userId;
  final String type; // 'earning', 'withdrawal', 'referral', 'bonus'
  final double amount;
  final String source; // Where the transaction came from
  final String description;
  final String status; // 'pending', 'completed', 'failed', 'cancelled'
  final Timestamp timestamp;
  final Map<String, dynamic>? metadata;

  TransactionModel({
    required this.transactionId,
    required this.userId,
    required this.type,
    required this.amount,
    required this.source,
    required this.description,
    required this.status,
    required this.timestamp,
    this.metadata,
  });

  factory TransactionModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    
    return TransactionModel(
      transactionId: doc.id,
      userId: data['userId'] ?? '',
      type: data['type'] ?? 'earning',
      amount: (data['amount'] ?? 0.0).toDouble(),
      source: data['source'] ?? 'unknown',
      description: data['description'] ?? '',
      status: data['status'] ?? 'pending',
      timestamp: data['timestamp'] ?? Timestamp.now(),
      metadata: data['metadata'] as Map<String, dynamic>?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'type': type,
      'amount': amount,
      'source': source,
      'description': description,
      'status': status,
      'timestamp': timestamp,
      'metadata': metadata,
    };
  }

  TransactionModel copyWith({
    String? transactionId,
    String? userId,
    String? type,
    double? amount,
    String? source,
    String? description,
    String? status,
    Timestamp? timestamp,
    Map<String, dynamic>? metadata,
  }) {
    return TransactionModel(
      transactionId: transactionId ?? this.transactionId,
      userId: userId ?? this.userId,
      type: type ?? this.type,
      amount: amount ?? this.amount,
      source: source ?? this.source,
      description: description ?? this.description,
      status: status ?? this.status,
      timestamp: timestamp ?? this.timestamp,
      metadata: metadata ?? this.metadata,
    );
  }

  // Helper methods
  DateTime get transactionTime => timestamp.toDate();
  
  bool get isEarning => type == 'earning';
  bool get isWithdrawal => type == 'withdrawal';
  bool get isReferral => type == 'referral';
  bool get isBonus => type == 'bonus';
  
  bool get isCompleted => status == 'completed';
  bool get isPending => status == 'pending';
  bool get isFailed => status == 'failed';
  bool get isCancelled => status == 'cancelled';
  
  String get formattedAmount {
    return amount.toStringAsFixed(2);
  }
  
  String get formattedTime {
    final dateTime = timestamp.toDate();
    final now = DateTime.now();
    
    if (dateTime.year == now.year && 
        dateTime.month == now.month && 
        dateTime.day == now.day) {
      return '${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
    } else if (dateTime.year == now.year && 
               dateTime.month == now.month && 
               dateTime.day == now.day - 1) {
      return 'Yesterday ${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
    } else {
      return '${dateTime.day}/${dateTime.month}/${dateTime.year.toString().substring(2)} ${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
    }
  }
  
  Color get amountColor {
    if (isEarning || isReferral || isBonus) {
      return Colors.green;
    } else if (isWithdrawal) {
      return Colors.red;
    }
    return Colors.grey;
  }
  
  IconData get icon {
    switch (type) {
      case 'earning':
        return Icons.trending_up;
      case 'withdrawal':
        return Icons.trending_down;
      case 'referral':
        return Icons.people;
      case 'bonus':
        return Icons.card_giftcard;
      default:
        return Icons.attach_money;
    }
  }
  
  String get sourceDisplayName {
    switch (source) {
      case 'group_ad':
        return 'Group Ad';
      case 'chat_ad':
        return 'Chat Ad';
      case 'file_download_ad':
        return 'File Download Ad';
      case 'daily_reward':
        return 'Daily Reward';
      case 'referral':
        return 'Referral Bonus';
      case 'withdrawal':
        return 'Withdrawal';
      default:
        return source.replaceAll('_', ' ').toUpperCase();
    }
  }
}