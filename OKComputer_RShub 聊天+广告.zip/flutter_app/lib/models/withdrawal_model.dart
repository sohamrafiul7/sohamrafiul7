import 'package:cloud_firestore/cloud_firestore.dart';

class WithdrawalModel {
  final String withdrawalId;
  final String userId;
  final double amount;
  final String paymentMethod; // 'bKash', 'Nagad', 'Rocket', 'Bank Transfer'
  final String accountNumber;
  final String? accountName;
  final String status; // 'pending', 'approved', 'rejected', 'completed', 'failed'
  final Timestamp requestedAt;
  final Timestamp? processedAt;
  final String? processedBy;
  final String? rejectionReason;
  final String? transactionId;
  final Map<String, dynamic>? metadata;

  WithdrawalModel({
    required this.withdrawalId,
    required this.userId,
    required this.amount,
    required this.paymentMethod,
    required this.accountNumber,
    this.accountName,
    this.status = 'pending',
    required this.requestedAt,
    this.processedAt,
    this.processedBy,
    this.rejectionReason,
    this.transactionId,
    this.metadata,
  });

  factory WithdrawalModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    
    return WithdrawalModel(
      withdrawalId: doc.id,
      userId: data['userId'] ?? '',
      amount: (data['amount'] ?? 0.0).toDouble(),
      paymentMethod: data['paymentMethod'] ?? 'bKash',
      accountNumber: data['accountNumber'] ?? '',
      accountName: data['accountName'],
      status: data['status'] ?? 'pending',
      requestedAt: data['requestedAt'] ?? Timestamp.now(),
      processedAt: data['processedAt'] as Timestamp?,
      processedBy: data['processedBy'],
      rejectionReason: data['rejectionReason'],
      transactionId: data['transactionId'],
      metadata: data['metadata'] as Map<String, dynamic>?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'amount': amount,
      'paymentMethod': paymentMethod,
      'accountNumber': accountNumber,
      'accountName': accountName,
      'status': status,
      'requestedAt': requestedAt,
      'processedAt': processedAt,
      'processedBy': processedBy,
      'rejectionReason': rejectionReason,
      'transactionId': transactionId,
      'metadata': metadata,
    };
  }

  WithdrawalModel copyWith({
    String? withdrawalId,
    String? userId,
    double? amount,
    String? paymentMethod,
    String? accountNumber,
    String? accountName,
    String? status,
    Timestamp? requestedAt,
    Timestamp? processedAt,
    String? processedBy,
    String? rejectionReason,
    String? transactionId,
    Map<String, dynamic>? metadata,
  }) {
    return WithdrawalModel(
      withdrawalId: withdrawalId ?? this.withdrawalId,
      userId: userId ?? this.userId,
      amount: amount ?? this.amount,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      accountNumber: accountNumber ?? this.accountNumber,
      accountName: accountName ?? this.accountName,
      status: status ?? this.status,
      requestedAt: requestedAt ?? this.requestedAt,
      processedAt: processedAt ?? this.processedAt,
      processedBy: processedBy ?? this.processedBy,
      rejectionReason: rejectionReason ?? this.rejectionReason,
      transactionId: transactionId ?? this.transactionId,
      metadata: metadata ?? this.metadata,
    );
  }

  // Helper methods
  DateTime get requestTime => requestedAt.toDate();
  DateTime? get processTime => processedAt?.toDate();
  
  bool get isPending => status == 'pending';
  bool get isApproved => status == 'approved';
  bool get isRejected => status == 'rejected';
  bool get isCompleted => status == 'completed';
  bool get isFailed => status == 'failed';
  
  String get formattedAmount {
    return amount.toStringAsFixed(2);
  }
  
  String get formattedTime {
    final dateTime = requestedAt.toDate();
    final now = DateTime.now();
    
    if (dateTime.year == now.year && 
        dateTime.month == now.month && 
        dateTime.day == now.day) {
      return '${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
    } else if (dateTime.year == now.year && 
               dateTime.month == now.month && 
               dateTime.day == now.day - 1) {
      return 'Yesterday ${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
    } else {
      return '${dateTime.day}/${dateTime.month}/${dateTime.year.toString().substring(2)} ${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
    }
  }
  
  String get statusDisplayName {
    switch (status) {
      case 'pending':
        return 'Pending';
      case 'approved':
        return 'Approved';
      case 'rejected':
        return 'Rejected';
      case 'completed':
        return 'Completed';
      case 'failed':
        return 'Failed';
      default:
        return status.toUpperCase();
    }
  }
  
  Color get statusColor {
    switch (status) {
      case 'pending':
        return Colors.orange;
      case 'approved':
        return Colors.blue;
      case 'rejected':
        return Colors.red;
      case 'completed':
        return Colors.green;
      case 'failed':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
  
  IconData get statusIcon {
    switch (status) {
      case 'pending':
        return Icons.pending;
      case 'approved':
        return Icons.check_circle;
      case 'rejected':
        return Icons.cancel;
      case 'completed':
        return Icons.done_all;
      case 'failed':
        return Icons.error;
      default:
        return Icons.help_outline;
    }
  }
  
  String get paymentMethodDisplayName {
    switch (paymentMethod) {
      case 'bKash':
        return 'bKash';
      case 'Nagad':
        return 'Nagad';
      case 'Rocket':
        return 'Rocket';
      case 'Bank Transfer':
        return 'Bank Transfer';
      default:
        return paymentMethod;
    }
  }
  
  IconData get paymentMethodIcon {
    switch (paymentMethod) {
      case 'bKash':
        return Icons.account_balance_wallet;
      case 'Nagad':
        return Icons.mobile_friendly;
      case 'Rocket':
        return Icons.rocket;
      case 'Bank Transfer':
        return Icons.account_balance;
      default:
        return Icons.payment;
    }
  }
}