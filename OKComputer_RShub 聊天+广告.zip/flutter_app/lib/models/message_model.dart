import 'package:cloud_firestore/cloud_firestore.dart';

class MessageModel {
  final String messageId;
  final String chatId;
  final String senderId;
  final String content;
  final String type; // text, image, video, audio, document, sticker
  final Timestamp timestamp;
  final bool isEdited;
  final bool isDeleted;
  final List<String> seenBy;
  final List<String> deliveredTo;
  final String? replyTo; // Message ID being replied to
  final Map<String, dynamic>? metadata; // Additional data based on type
  final Map<String, dynamic>? adData; // Ad-related data

  MessageModel({
    required this.messageId,
    required this.chatId,
    required this.senderId,
    required this.content,
    required this.type,
    required this.timestamp,
    this.isEdited = false,
    this.isDeleted = false,
    this.seenBy = const [],
    this.deliveredTo = const [],
    this.replyTo,
    this.metadata,
    this.adData,
  });

  factory MessageModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    
    return MessageModel(
      messageId: doc.id,
      chatId: data['chatId'] ?? '',
      senderId: data['senderId'] ?? '',
      content: data['content'] ?? '',
      type: data['type'] ?? 'text',
      timestamp: data['timestamp'] ?? Timestamp.now(),
      isEdited: data['isEdited'] ?? false,
      isDeleted: data['isDeleted'] ?? false,
      seenBy: List<String>.from(data['seenBy'] ?? []),
      deliveredTo: List<String>.from(data['deliveredTo'] ?? []),
      replyTo: data['replyTo'],
      metadata: data['metadata'] as Map<String, dynamic>?,
      adData: data['adData'] as Map<String, dynamic>?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'chatId': chatId,
      'senderId': senderId,
      'content': content,
      'type': type,
      'timestamp': timestamp,
      'isEdited': isEdited,
      'isDeleted': isDeleted,
      'seenBy': seenBy,
      'deliveredTo': deliveredTo,
      'replyTo': replyTo,
      'metadata': metadata,
      'adData': adData,
    };
  }

  MessageModel copyWith({
    String? messageId,
    String? chatId,
    String? senderId,
    String? content,
    String? type,
    Timestamp? timestamp,
    bool? isEdited,
    bool? isDeleted,
    List<String>? seenBy,
    List<String>? deliveredTo,
    String? replyTo,
    Map<String, dynamic>? metadata,
    Map<String, dynamic>? adData,
  }) {
    return MessageModel(
      messageId: messageId ?? this.messageId,
      chatId: chatId ?? this.chatId,
      senderId: senderId ?? this.senderId,
      content: content ?? this.content,
      type: type ?? this.type,
      timestamp: timestamp ?? this.timestamp,
      isEdited: isEdited ?? this.isEdited,
      isDeleted: isDeleted ?? this.isDeleted,
      seenBy: seenBy ?? this.seenBy,
      deliveredTo: deliveredTo ?? this.deliveredTo,
      replyTo: replyTo ?? this.replyTo,
      metadata: metadata ?? this.metadata,
      adData: adData ?? this.adData,
    );
  }

  // Helper methods
  bool get isText => type == 'text';
  bool get isImage => type == 'image';
  bool get isVideo => type == 'video';
  bool get isAudio => type == 'audio';
  bool get isDocument => type == 'document';
  bool get isSticker => type == 'sticker';
  
  bool isSentBy(String userId) => senderId == userId;
  bool isSeenBy(String userId) => seenBy.contains(userId);
  bool isDeliveredTo(String userId) => deliveredTo.contains(userId);
  
  bool get isSeen => seenBy.isNotEmpty;
  bool get isDelivered => deliveredTo.isNotEmpty;
  
  DateTime get messageTime => timestamp.toDate();
  
  String get formattedTime {
    final dateTime = timestamp.toDate();
    final now = DateTime.now();
    
    if (dateTime.year == now.year && 
        dateTime.month == now.month && 
        dateTime.day == now.day) {
      // Today - show time only
      return '${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
    } else if (dateTime.year == now.year && 
               dateTime.month == now.month && 
               dateTime.day == now.day - 1) {
      // Yesterday
      return 'Yesterday ${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
    } else {
      // Other dates
      return '${dateTime.day}/${dateTime.month}/${dateTime.year.toString().substring(2)}';
    }
  }

  // Media metadata helpers
  String? get fileName => metadata?['fileName'];
  String? get fileSize => metadata?['fileSize'];
  String? get fileUrl => metadata?['fileUrl'];
  String? get thumbnailUrl => metadata?['thumbnailUrl'];
  int? get duration => metadata?['duration']; // For audio/video in seconds
  int? get width => metadata?['width']; // For images/videos
  int? get height => metadata?['height']; // For images/videos
  
  // Ad data helpers
  bool get hasAd => adData != null;
  String? get adType => adData?['adType'];
  bool get isAdMessage => adData?['isAdMessage'] ?? false;
  double? get adRevenue => adData?['adRevenue']?.toDouble();
  String? get adId => adData?['adId'];
}

// Chat Model for conversations
class ChatModel {
  final String chatId;
  final String type; // 'individual' or 'group'
  final List<String> participants;
  final Map<String, dynamic> lastMessage;
  final Timestamp lastMessageTime;
  final Map<String, int> unreadCount;
  final Map<String, dynamic>? metadata; // For group info, settings, etc.
  final Map<String, dynamic>? adSettings; // Chat-specific ad settings

  ChatModel({
    required this.chatId,
    required this.type,
    required this.participants,
    required this.lastMessage,
    required this.lastMessageTime,
    this.unreadCount = const {},
    this.metadata,
    this.adSettings,
  });

  factory ChatModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    
    return ChatModel(
      chatId: doc.id,
      type: data['type'] ?? 'individual',
      participants: List<String>.from(data['participants'] ?? []),
      lastMessage: data['lastMessage'] ?? {},
      lastMessageTime: data['lastMessageTime'] ?? Timestamp.now(),
      unreadCount: Map<String, int>.from(data['unreadCount'] ?? {}),
      metadata: data['metadata'] as Map<String, dynamic>?,
      adSettings: data['adSettings'] as Map<String, dynamic>?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'type': type,
      'participants': participants,
      'lastMessage': lastMessage,
      'lastMessageTime': lastMessageTime,
      'unreadCount': unreadCount,
      'metadata': metadata,
      'adSettings': adSettings,
    };
  }

  // Helper methods
  bool get isGroup => type == 'group';
  bool get isIndividual => type == 'individual';
  
  String get chatName {
    if (isGroup) {
      return metadata?['name'] ?? 'Group Chat';
    }
    return 'Individual Chat';
  }

  String? get groupImage => metadata?['groupImage'];
  String? get groupDescription => metadata?['description'];
  String? get createdBy => metadata?['createdBy'];
  
  int get participantCount => participants.length;
  
  bool hasUnreadMessages(String userId) {
    return (unreadCount[userId] ?? 0) > 0;
  }

  int getUnreadCount(String userId) {
    return unreadCount[userId] ?? 0;
  }

  // Ad settings helpers
  bool adsEnabledForUser(String userId) {
    return adSettings?[userId]?['adsEnabled'] ?? false;
  }

  int getAdFrequency(String userId) {
    return adSettings?[userId]?['adFrequency'] ?? 10;
  }
}