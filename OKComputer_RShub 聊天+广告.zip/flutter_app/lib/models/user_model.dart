import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String phone;
  final String name;
  final String profileImage;
  final String bio;
  final bool onlineStatus;
  final double walletBalance;
  final double totalEarning;
  final double todayEarning;
  final String deviceId;
  final DateTime createdAt;
  final DateTime? updatedAt;
  final DateTime? lastSeen;
  final bool isActive;
  final bool isPremium;
  final Map<String, dynamic>? adSettings;
  final List<String>? blockedUsers;
  final List<String>? reportedBy;

  UserModel({
    required this.uid,
    required this.phone,
    required this.name,
    required this.profileImage,
    required this.bio,
    required this.onlineStatus,
    required this.walletBalance,
    required this.totalEarning,
    this.todayEarning = 0.0,
    required this.deviceId,
    required this.createdAt,
    this.updatedAt,
    this.lastSeen,
    this.isActive = true,
    this.isPremium = false,
    this.adSettings,
    this.blockedUsers,
    this.reportedBy,
  });

  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    
    return UserModel(
      uid: doc.id,
      phone: data['phone'] ?? '',
      name: data['name'] ?? '',
      profileImage: data['profileImage'] ?? '',
      bio: data['bio'] ?? '',
      onlineStatus: data['onlineStatus'] ?? false,
      walletBalance: (data['walletBalance'] ?? 0.0).toDouble(),
      totalEarning: (data['totalEarning'] ?? 0.0).toDouble(),
      todayEarning: (data['todayEarning'] ?? 0.0).toDouble(),
      deviceId: data['deviceId'] ?? '',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
      lastSeen: (data['lastSeen'] as Timestamp?)?.toDate(),
      isActive: data['isActive'] ?? true,
      isPremium: data['isPremium'] ?? false,
      adSettings: data['adSettings'] as Map<String, dynamic>?,
      blockedUsers: List<String>.from(data['blockedUsers'] ?? []),
      reportedBy: List<String>.from(data['reportedBy'] ?? []),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'phone': phone,
      'name': name,
      'profileImage': profileImage,
      'bio': bio,
      'onlineStatus': onlineStatus,
      'walletBalance': walletBalance,
      'totalEarning': totalEarning,
      'todayEarning': todayEarning,
      'deviceId': deviceId,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': updatedAt != null ? Timestamp.fromDate(updatedAt!) : null,
      'lastSeen': lastSeen != null ? Timestamp.fromDate(lastSeen!) : null,
      'isActive': isActive,
      'isPremium': isPremium,
      'adSettings': adSettings,
      'blockedUsers': blockedUsers,
      'reportedBy': reportedBy,
    };
  }

  UserModel copyWith({
    String? uid,
    String? phone,
    String? name,
    String? profileImage,
    String? bio,
    bool? onlineStatus,
    double? walletBalance,
    double? totalEarning,
    double? todayEarning,
    String? deviceId,
    DateTime? createdAt,
    DateTime? updatedAt,
    DateTime? lastSeen,
    bool? isActive,
    bool? isPremium,
    Map<String, dynamic>? adSettings,
    List<String>? blockedUsers,
    List<String>? reportedBy,
  }) {
    return UserModel(
      uid: uid ?? this.uid,
      phone: phone ?? this.phone,
      name: name ?? this.name,
      profileImage: profileImage ?? this.profileImage,
      bio: bio ?? this.bio,
      onlineStatus: onlineStatus ?? this.onlineStatus,
      walletBalance: walletBalance ?? this.walletBalance,
      totalEarning: totalEarning ?? this.totalEarning,
      todayEarning: todayEarning ?? this.todayEarning,
      deviceId: deviceId ?? this.deviceId,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      lastSeen: lastSeen ?? this.lastSeen,
      isActive: isActive ?? this.isActive,
      isPremium: isPremium ?? this.isPremium,
      adSettings: adSettings ?? this.adSettings,
      blockedUsers: blockedUsers ?? this.blockedUsers,
      reportedBy: reportedBy ?? this.reportedBy,
    );
  }

  // Helper methods
  String get displayName => name.isNotEmpty ? name : phone;
  
  String get initials {
    if (name.isEmpty) return phone.substring(0, 2).toUpperCase();
    final parts = name.split(' ');
    if (parts.length == 1) return parts[0][0].toUpperCase();
    return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
  }

  bool get canWithdraw => walletBalance >= 100.0;
  
  bool isBlocked(String userId) {
    return blockedUsers?.contains(userId) ?? false;
  }

  // Ad settings helpers
  bool get groupAdsEnabled => adSettings?['groupAdsEnabled'] ?? false;
  bool get chatAdsEnabled => adSettings?['chatAdsEnabled'] ?? false;
  int get groupAdFrequency => adSettings?['groupAdFrequency'] ?? 10;
  int get chatAdFrequency => adSettings?['chatAdFrequency'] ?? 20;

  Map<String, dynamic> getDefaultAdSettings() {
    return {
      'groupAdsEnabled': false,
      'chatAdsEnabled': false,
      'groupAdFrequency': 10,
      'chatAdFrequency': 20,
      'autoPlayAds': true,
      'adSoundEnabled': false,
    };
  }
}