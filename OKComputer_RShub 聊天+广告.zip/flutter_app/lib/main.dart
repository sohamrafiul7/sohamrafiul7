import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import 'config/app_config.dart';
import 'config/theme.dart';
import 'routes/app_pages.dart';
import 'services/firebase_service.dart';
import 'services/ad_service.dart';
import 'controllers/auth_controller.dart';
import 'controllers/theme_controller.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize local storage
  await GetStorage.init();
  
  // Initialize Firebase
  await Firebase.initializeApp();
  
  // Initialize Mobile Ads
  MobileAds.instance.initialize();
  
  // Initialize services
  await FirebaseService.instance.initialize();
  await AdService.instance.initialize();
  
  // Initialize controllers
  Get.put(AuthController());
  Get.put(ThemeController());
  
  runApp(const RShubApp());
}

class RShubApp extends StatelessWidget {
  const RShubApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final themeController = Get.find<ThemeController>();
    
    return Obx(() => GetMaterialApp(
      title: 'RShub',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: themeController.themeMode.value,
      initialRoute: AppPages.INITIAL,
      getPages: AppPages.routes,
      defaultTransition: Transition.cupertino,
      transitionDuration: const Duration(milliseconds: 300),
      locale: const Locale('en', 'US'),
      fallbackLocale: const Locale('en', 'US'),
    ));
  }
}