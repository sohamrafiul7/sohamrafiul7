import 'package:get/get.dart';
import 'package:rshub/bindings/auth_binding.dart';
import 'package:rshub/bindings/home_binding.dart';
import 'package:rshub/bindings/chat_binding.dart';
import 'package:rshub/bindings/wallet_binding.dart';
import 'package:rshub/middleware/auth_middleware.dart';

import '../screens/splash/splash_screen.dart';
import '../screens/auth/login_screen.dart';
import '../screens/auth/otp_screen.dart';
import '../screens/auth/profile_setup_screen.dart';
import '../screens/home/home_screen.dart';
import '../screens/chat/chat_screen.dart';
import '../screens/group/group_chat_screen.dart';
import '../screens/group/create_group_screen.dart';
import '../screens/wallet/wallet_screen.dart';
import '../screens/wallet/withdraw_screen.dart';
import '../screens/settings/settings_screen.dart';
import '../screens/settings/ads_settings_screen.dart';

part 'app_routes.dart';

class AppPages {
  AppPages._();

  static const INITIAL = Routes.SPLASH;

  static final routes = [
    // Splash Screen
    GetPage(
      name: _Paths.SPLASH,
      page: () => const SplashScreen(),
      binding: AuthBinding(),
    ),
    
    // Auth Screens
    GetPage(
      name: _Paths.LOGIN,
      page: () => const LoginScreen(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: _Paths.OTP,
      page: () => OTPScreen(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: _Paths.PROFILE_SETUP,
      page: () => const ProfileSetupScreen(),
      binding: AuthBinding(),
    ),
    
    // Main App Screens
    GetPage(
      name: _Paths.HOME,
      page: () => const HomeScreen(),
      binding: HomeBinding(),
      middlewares: [AuthMiddleware()],
    ),
    
    // Chat Screens
    GetPage(
      name: _Paths.CHAT,
      page: () => const ChatScreen(),
      binding: ChatBinding(),
      middlewares: [AuthMiddleware()],
    ),
    
    // Group Screens
    GetPage(
      name: _Paths.GROUP_CHAT,
      page: () => const GroupChatScreen(),
      binding: ChatBinding(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: _Paths.CREATE_GROUP,
      page: () => const CreateGroupScreen(),
      binding: ChatBinding(),
      middlewares: [AuthMiddleware()],
    ),
    
    // Wallet Screens
    GetPage(
      name: _Paths.WALLET,
      page: () => const WalletScreen(),
      binding: WalletBinding(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: _Paths.WITHDRAW,
      page: () => const WithdrawScreen(),
      binding: WalletBinding(),
      middlewares: [AuthMiddleware()],
    ),
    
    // Settings Screens
    GetPage(
      name: _Paths.SETTINGS,
      page: () => const SettingsScreen(),
      binding: HomeBinding(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: _Paths.ADS_SETTINGS,
      page: () => const AdsSettingsScreen(),
      binding: HomeBinding(),
      middlewares: [AuthMiddleware()],
    ),
  ];
}