part of 'app_pages.dart';

abstract class Routes {
  Routes._();

  // Initial route
  static const SPLASH = _Paths.SPLASH;
  
  // Auth routes
  static const LOGIN = _Paths.LOGIN;
  static const OTP = _Paths.OTP;
  static const PROFILE_SETUP = _Paths.PROFILE_SETUP;
  
  // Main app routes
  static const HOME = _Paths.HOME;
  
  // Chat routes
  static const CHAT = _Paths.CHAT;
  
  // Group routes
  static const GROUP_CHAT = _Paths.GROUP_CHAT;
  static const CREATE_GROUP = _Paths.CREATE_GROUP;
  
  // Wallet routes
  static const WALLET = _Paths.WALLET;
  static const WITHDRAW = _Paths.WITHDRAW;
  
  // Settings routes
  static const SETTINGS = _Paths.SETTINGS;
  static const ADS_SETTINGS = _Paths.ADS_SETTINGS;
}

abstract class _Paths {
  _Paths._();

  // Initial route
  static const String SPLASH = '/splash';
  
  // Auth routes
  static const String LOGIN = '/login';
  static const String OTP = '/otp';
  static const String PROFILE_SETUP = '/profile-setup';
  
  // Main app routes
  static const String HOME = '/home';
  
  // Chat routes
  static const String CHAT = '/chat';
  
  // Group routes
  static const String GROUP_CHAT = '/group-chat';
  static const String CREATE_GROUP = '/create-group';
  
  // Wallet routes
  static const String WALLET = '/wallet';
  static const String WITHDRAW = '/withdraw';
  
  // Settings routes
  static const String SETTINGS = '/settings';
  static const String ADS_SETTINGS = '/ads-settings';
}