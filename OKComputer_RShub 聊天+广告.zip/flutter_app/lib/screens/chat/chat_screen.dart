import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cached_network_image/cached_network_image.dart';

import '../../controllers/chat_controller.dart';
import '../../controllers/auth_controller.dart';
import '../../models/message_model.dart';
import '../../models/user_model.dart';
import '../../config/theme.dart';
import '../../widgets/message_bubble.dart';
import '../../widgets/chat_input_field.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final ChatController chatController = Get.find<ChatController>();
  final AuthController authController = Get.find<AuthController>();
  final TextEditingController messageController = TextEditingController();
  final ScrollController scrollController = ScrollController();
  final FocusNode messageFocusNode = FocusNode();
  
  String? chatId;
  String? otherUserId;
  bool _isLoadingChat = true;

  @override
  void initState() {
    super.initState();
    _initializeChat();
    
    // Scroll to bottom when new messages arrive
    ever(chatController.messages, (_) {
      _scrollToBottom();
    });
  }

  @override
  void dispose() {
    messageController.dispose();
    scrollController.dispose();
    messageFocusNode.dispose();
    
    // Clear current chat when leaving
    chatController.currentChat.value = null;
    chatController.chatUser.value = null;
    
    super.dispose();
  }

  Future<void> _initializeChat() async {
    // Get chat ID from arguments
    chatId = Get.arguments?['chatId'];
    otherUserId = Get.arguments?['userId'];
    
    if (chatId != null) {
      // Existing chat
      await chatController.loadChat(chatId!);
    } else if (otherUserId != null) {
      // New chat
      final newChatId = await chatController.createIndividualChat(otherUserId!);
      if (newChatId != null) {
        chatId = newChatId;
        await chatController.loadChat(chatId!);
      }
    }
    
    setState(() {
      _isLoadingChat = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.chatBackground,
      appBar: _buildAppBar(),
      body: _isLoadingChat
          ? const Center(child: CircularProgressIndicator())
          : _buildChatBody(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
      elevation: 1,
      title: Obx(() {
        final chatUser = chatController.chatUser.value;
        final currentChat = chatController.currentChat.value;
        
        if (chatUser == null) {
          return Text(
            currentChat?.chatName ?? 'Chat',
            style: Theme.of(context).appBarTheme.titleTextStyle,
          );
        }
        
        return Row(
          children: [
            // Profile Image
            Hero(
              tag: 'profile-${chatUser.uid}',
              child: CircleAvatar(
                radius: 20,
                backgroundColor: AppTheme.primaryColor.withOpacity(0.1),
                backgroundImage: chatUser.profileImage.isNotEmpty
                    ? CachedNetworkImageProvider(chatUser.profileImage)
                    : null,
                child: chatUser.profileImage.isEmpty
                    ? Text(
                        chatUser.initials,
                        style: TextStyle(
                          color: AppTheme.primaryColor,
                          fontWeight: FontWeight.bold,
                        ),
                      )
                    : null,
              ),
            ),
            
            const SizedBox(width: 12),
            
            // Name and Status
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  chatUser.displayName,
                  style: Theme.of(context).appBarTheme.titleTextStyle,
                ),
                
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: chatUser.onlineStatus 
                            ? AppTheme.onlineColor 
                            : AppTheme.offlineColor,
                        shape: BoxShape.circle,
                      ),
                    ),
                    
                    const SizedBox(width: 4),
                    
                    Text(
                      chatUser.onlineStatus ? 'Online' : 'Offline',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        );
      }),
      
      actions: [
        IconButton(
          icon: const Icon(Icons.call),
          onPressed: _handleVoiceCall,
        ),
        IconButton(
          icon: const Icon(Icons.videocam),
          onPressed: _handleVideoCall,
        ),
        PopupMenuButton<String>(
          onSelected: _handleMenuAction,
          itemBuilder: (context) => [
            const PopupMenuItem(
              value: 'view_profile',
              child: Text('View Profile'),
            ),
            const PopupMenuItem(
              value: 'media',
              child: Text('Media'),
            ),
            const PopupMenuItem(
              value: 'search',
              child: Text('Search'),
            ),
            const PopupMenuItem(
              value: 'clear_chat',
              child: Text('Clear Chat'),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildChatBody() {
    return Column(
      children: [
        // Messages List
        Expanded(
          child: Obx(() {
            final messages = chatController.messages;
            
            if (messages.isEmpty) {
              return _buildEmptyChat();
            }
            
            return ListView.builder(
              controller: scrollController,
              reverse: true,
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final message = messages[index];
                final isCurrentUser = message.senderId == authController.currentUserId;
                
                return MessageBubble(
                  message: message,
                  isCurrentUser: isCurrentUser,
                  onLongPress: () => _handleMessageLongPress(message),
                  onReply: () => chatController.setReplyToMessage(message),
                );
              },
            );
          }),
        ),
        
        // Typing Indicator
        _buildTypingIndicator(),
        
        // Reply Preview
        Obx(() {
          final replyToMessage = chatController.replyToMessage.value;
          if (replyToMessage == null) return const SizedBox.shrink();
          
          return _buildReplyPreview(replyToMessage);
        }),
        
        // Message Input
        _buildMessageInput(),
      ],
    );
  }

  Widget _buildEmptyChat() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.chat_bubble_outline,
            size: 80,
            color: AppTheme.textHint.withOpacity(0.5),
          ),
          
          const SizedBox(height: 16),
          
          Text(
            'Start a conversation',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              color: AppTheme.textSecondary,
            ),
          ),
          
          const SizedBox(height: 8),
          
          Text(
            'Send a message to begin chatting',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: AppTheme.textHint,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTypingIndicator() {
    return Obx(() {
      final chatUser = chatController.chatUser.value;
      if (chatUser == null || !chatUser.onlineStatus) {
        return const SizedBox.shrink();
      }
      
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        alignment: Alignment.centerLeft,
        child: Row(
          children: [
            Text(
              '${chatUser.displayName} is typing',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: AppTheme.textSecondary,
                fontStyle: FontStyle.italic,
              ),
            ),
            
            const SizedBox(width: 4),
            
            _buildTypingAnimation(),
          ],
        ),
      );
    });
  }

  Widget _buildTypingAnimation() {
    return Row(
      children: List.generate(3, (index) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 1),
          width: 4,
          height: 4,
          decoration: BoxDecoration(
            color: AppTheme.textSecondary,
            shape: BoxShape.circle,
          ),
        );
      }),
    );
  }

  Widget _buildReplyPreview(MessageModel replyToMessage) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: AppTheme.primaryColor.withOpacity(0.3),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Replying to',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppTheme.primaryColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                
                const SizedBox(height: 4),
                
                Text(
                  replyToMessage.content,
                  style: Theme.of(context).textTheme.bodyMedium,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          
          IconButton(
            icon: const Icon(Icons.close, size: 20),
            onPressed: chatController.clearReplyToMessage,
          ),
        ],
      ),
    );
  }

  Widget _buildMessageInput() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            // Attachment Button
            IconButton(
              icon: const Icon(Icons.attach_file),
              onPressed: _showAttachmentOptions,
            ),
            
            // Message Input
            Expanded(
              child: ChatInputField(
                controller: messageController,
                focusNode: messageFocusNode,
                hintText: 'Type a message...',
                onChanged: (text) {
                  if (text.isNotEmpty && !chatController.isTyping.value) {
                    chatController.startTyping(chatId!);
                  } else if (text.isEmpty && chatController.isTyping.value) {
                    chatController.stopTyping(chatId!);
                  }
                },
                onSubmitted: _handleSendMessage,
              ),
            ),
            
            // Send Button
            Obx(() {
              final hasText = messageController.text.trim().isNotEmpty;
              final isSending = chatController.isSending.value;
              
              return IconButton(
                icon: isSending
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Icon(
                        hasText ? Icons.send : Icons.mic,
                        color: hasText ? AppTheme.primaryColor : AppTheme.textSecondary,
                      ),
                onPressed: isSending ? null : _handleSendOrRecord,
              );
            }),
          ],
        ),
      ),
    );
  }

  void _handleSendMessage(String text) {
    if (text.trim().isEmpty) return;
    
    final replyTo = chatController.replyToMessageId.value.isNotEmpty
        ? chatController.replyToMessageId.value
        : null;
    
    chatController.sendMessage(
      chatId: chatId!,
      content: text.trim(),
      replyTo: replyTo,
    );
    
    messageController.clear();
    chatController.clearReplyToMessage();
    chatController.stopTyping(chatId!);
  }

  void _handleSendOrRecord() {
    final text = messageController.text.trim();
    
    if (text.isNotEmpty) {
      _handleSendMessage(text);
    } else {
      _handleVoiceRecording();
    }
  }

  void _handleVoiceRecording() {
    // Implement voice recording
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Voice recording coming soon!')),
    );
  }

  void _showAttachmentOptions() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.image),
                title: const Text('Photo'),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage();
                },
              ),
              ListTile(
                leading: const Icon(Icons.videocam),
                title: const Text('Video'),
                onTap: () {
                  Navigator.pop(context);
                  _pickVideo();
                },
              ),
              ListTile(
                leading: const Icon(Icons.audiotrack),
                title: const Text('Audio'),
                onTap: () {
                  Navigator.pop(context);
                  _pickAudio();
                },
              ),
              ListTile(
                leading: const Icon(Icons.insert_drive_file),
                title: const Text('Document'),
                onTap: () {
                  Navigator.pop(context);
                  _pickDocument();
                },
              ),
              ListTile(
                leading: const Icon(Icons.location_on),
                title: const Text('Location'),
                onTap: () {
                  Navigator.pop(context);
                  _shareLocation();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _pickImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
    );
    
    if (image != null && chatId != null) {
      chatController.sendMediaMessage(
        chatId: chatId!,
        file: image,
        type: 'image',
      );
    }
  }

  Future<void> _pickVideo() async {
    final ImagePicker picker = ImagePicker();
    final XFile? video = await picker.pickVideo(
      source: ImageSource.gallery,
    );
    
    if (video != null && chatId != null) {
      chatController.sendMediaMessage(
        chatId: chatId!,
        file: video,
        type: 'video',
      );
    }
  }

  Future<void> _pickAudio() async {
    // Implement audio picking
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Audio sharing coming soon!')),
    );
  }

  Future<void> _pickDocument() async {
    // Implement document picking
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Document sharing coming soon!')),
    );
  }

  Future<void> _shareLocation() async {
    // Implement location sharing
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Location sharing coming soon!')),
    );
  }

  void _handleMessageLongPress(MessageModel message) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (message.senderId == authController.currentUserId) ...[
                ListTile(
                  leading: const Icon(Icons.reply),
                  title: const Text('Reply'),
                  onTap: () {
                    Navigator.pop(context);
                    chatController.setReplyToMessage(message);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.edit),
                  title: const Text('Edit'),
                  onTap: () {
                    Navigator.pop(context);
                    _showEditMessageDialog(message);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.delete),
                  title: const Text('Delete for me'),
                  onTap: () {
                    Navigator.pop(context);
                    chatController.deleteMessage(chatId!, message.messageId);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.delete_forever),
                  title: const Text('Delete for everyone'),
                  onTap: () {
                    Navigator.pop(context);
                    chatController.deleteMessage(
                      chatId!, 
                      message.messageId,
                      deleteForEveryone: true,
                    );
                  },
                ),
              ] else ...[
                ListTile(
                  leading: const Icon(Icons.reply),
                  title: const Text('Reply'),
                  onTap: () {
                    Navigator.pop(context);
                    chatController.setReplyToMessage(message);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.report),
                  title: const Text('Report'),
                  onTap: () {
                    Navigator.pop(context);
                    _reportMessage(message);
                  },
                ),
              ],
              ListTile(
                leading: const Icon(Icons.copy),
                title: const Text('Copy'),
                onTap: () {
                  Navigator.pop(context);
                  _copyMessage(message);
                },
              ),
              ListTile(
                leading: const Icon(Icons.share),
                title: const Text('Share'),
                onTap: () {
                  Navigator.pop(context);
                  _shareMessage(message);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _showEditMessageDialog(MessageModel message) {
    final editController = TextEditingController(text: message.content);
    
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Edit Message'),
          content: TextField(
            controller: editController,
            decoration: const InputDecoration(
              hintText: 'Enter new message',
            ),
            maxLines: 3,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final newText = editController.text.trim();
                if (newText.isNotEmpty && newText != message.content) {
                  chatController.editMessage(chatId!, message.messageId, newText);
                }
                Navigator.pop(context);
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }

  void _reportMessage(MessageModel message) {
    // Implement message reporting
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Message reported')),
    );
  }

  void _copyMessage(MessageModel message) {
    // Implement message copying
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Message copied to clipboard')),
    );
  }

  void _shareMessage(MessageModel message) {
    // Implement message sharing
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Message sharing coming soon!')),
    );
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (scrollController.hasClients) {
        scrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _handleVoiceCall() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Voice calls coming soon!')),
    );
  }

  void _handleVideoCall() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Video calls coming soon!')),
    );
  }

  void _handleMenuAction(String value) {
    switch (value) {
      case 'view_profile':
        // Navigate to profile
        break;
      case 'media':
        // Show media gallery
        break;
      case 'search':
        // Search messages
        break;
      case 'clear_chat':
        // Clear chat history
        break;
    }
  }
}