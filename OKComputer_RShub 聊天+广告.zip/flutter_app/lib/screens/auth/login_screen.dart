import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter/services.dart';
import 'package:country_code_picker/country_code_picker.dart';

import '../../controllers/auth_controller.dart';
import '../../config/theme.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_textfield.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final AuthController authController = Get.find<AuthController>();
  final TextEditingController phoneController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  
  String countryCode = '+880';
  bool isValidPhone = false;

  @override
  void dispose() {
    phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 60),
                
                // App Logo
                Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    color: AppTheme.primaryColor,
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: const Icon(
                    Icons.chat,
                    size: 60,
                    color: Colors.white,
                  ),
                ),
                
                const SizedBox(height: 32),
                
                // App Title
                Text(
                  'RShub',
                  style: Theme.of(context).textTheme.displaySmall?.copyWith(
                    color: AppTheme.primaryColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                
                const SizedBox(height: 8),
                
                Text(
                  'Chat • Connect • Earn',
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: AppTheme.textSecondary,
                  ),
                ),
                
                const SizedBox(height: 48),
                
                // Welcome Text
                Text(
                  'Welcome to RShub',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                
                const SizedBox(height: 8),
                
                Text(
                  'Enter your phone number to continue',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: AppTheme.textSecondary,
                  ),
                ),
                
                const SizedBox(height: 32),
                
                // Phone Number Input
                Container(
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      // Country Code Picker
                      CountryCodePicker(
                        onChanged: (code) {
                          setState(() {
                            countryCode = code.dialCode!;
                          });
                        },
                        initialSelection: 'BD',
                        favorite: const ['+880', 'BD'],
                        showCountryOnly: false,
                        showOnlyCountryWhenClosed: false,
                        alignLeft: false,
                        textStyle: Theme.of(context).textTheme.bodyLarge,
                      ),
                      
                      // Phone Number Input
                      Expanded(
                        child: CustomTextField(
                          controller: phoneController,
                          hintText: 'Phone Number',
                          keyboardType: TextInputType.phone,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                            LengthLimitingTextInputFormatter(11),
                          ],
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your phone number';
                            }
                            if (countryCode == '+880' && value.length != 11) {
                              return 'Please enter a valid 11-digit number';
                            }
                            return null;
                          },
                          onChanged: (value) {
                            setState(() {
                              isValidPhone = _validatePhoneNumber(value);
                            });
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 24),
                
                // Terms and Privacy
                RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppTheme.textSecondary,
                    ),
                    children: [
                      const TextSpan(text: 'By continuing, you agree to our '),
                      TextSpan(
                        text: 'Terms of Service',
                        style: const TextStyle(
                          color: AppTheme.primaryColor,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                      const TextSpan(text: ' and '),
                      TextSpan(
                        text: 'Privacy Policy',
                        style: const TextStyle(
                          color: AppTheme.primaryColor,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 32),
                
                // Continue Button
                Obx(() => CustomButton(
                  text: 'Continue',
                  isLoading: authController.isLoading.value,
                  onPressed: isValidPhone && !authController.isLoading.value
                      ? _handleContinue
                      : null,
                )),
                
                const SizedBox(height: 24),
                
                // Or Divider
                Row(
                  children: [
                    const Expanded(
                      child: Divider(color: AppTheme.textHint),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Text(
                        'OR',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ),
                    const Expanded(
                      child: Divider(color: AppTheme.textHint),
                    ),
                  ],
                ),
                
                const SizedBox(height: 24),
                
                // Social Login Options
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _socialLoginButton(
                      icon: Icons.g_mobiledata,
                      color: Colors.red,
                      onTap: () => _handleSocialLogin('google'),
                    ),
                    const SizedBox(width: 16),
                    _socialLoginButton(
                      icon: Icons.facebook,
                      color: Colors.blue,
                      onTap: () => _handleSocialLogin('facebook'),
                    ),
                    const SizedBox(width: 16),
                    _socialLoginButton(
                      icon: Icons.apple,
                      color: Colors.black,
                      onTap: () => _handleSocialLogin('apple'),
                    ),
                  ],
                ),
                
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }

  bool _validatePhoneNumber(String phone) {
    if (phone.isEmpty) return false;
    
    if (countryCode == '+880') {
      // Bangladesh phone number validation
      return phone.length == 11 && phone.startsWith('01');
    }
    
    // Add more country validations as needed
    return phone.length >= 10;
  }

  void _handleContinue() async {
    if (_formKey.currentState!.validate()) {
      final fullPhoneNumber = countryCode + phoneController.text.trim();
      
      // Check if user exists
      final userExists = await authController.checkUserExists(fullPhoneNumber);
      
      if (userExists) {
        // Existing user - show confirmation dialog
        _showLoginConfirmationDialog(fullPhoneNumber);
      } else {
        // New user - proceed directly
        authController.verifyPhoneNumber(fullPhoneNumber, isLogin: false);
      }
    }
  }

  void _showLoginConfirmationDialog(String phoneNumber) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Account Found'),
        content: Text(
          'An account with $phoneNumber already exists. Do you want to login?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              authController.verifyPhoneNumber(phoneNumber, isLogin: true);
            },
            child: const Text('Login'),
          ),
        ],
      ),
    );
  }

  Widget _socialLoginButton({
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Icon(
          icon,
          size: 30,
          color: color,
        ),
      ),
    );
  }

  void _handleSocialLogin(String provider) {
    // Implement social login
    Helpers.showInfoSnackBar('$provider login coming soon!');
  }
}