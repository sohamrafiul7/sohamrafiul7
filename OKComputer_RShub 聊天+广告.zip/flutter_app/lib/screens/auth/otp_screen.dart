import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter/services.dart';
import 'package:pinput/pinput.dart';

import '../../controllers/auth_controller.dart';
import '../../config/theme.dart';
import '../../widgets/custom_button.dart';

class OTPScreen extends StatefulWidget {
  OTPScreen({Key? key}) : super(key: key);

  @override
  State<OTPScreen> createState() => _OTPScreenState();
}

class _OTPScreenState extends State<OTPScreen> {
  final AuthController authController = Get.find<AuthController>();
  final TextEditingController otpController = TextEditingController();
  final FocusNode otpFocusNode = FocusNode();
  
  int _remainingTime = 60;
  bool _canResend = false;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  @override
  void dispose() {
    otpController.dispose();
    otpFocusNode.dispose();
    super.dispose();
  }

  void _startTimer() {
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) {
        setState(() {
          _remainingTime--;
          if (_remainingTime > 0) {
            _startTimer();
          } else {
            _canResend = true;
          }
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        title: const Text('Verify Phone Number'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 40),
              
              // OTP Icon
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  color: AppTheme.primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Icon(
                  Icons.sms,
                  size: 50,
                  color: AppTheme.primaryColor,
                ),
              ),
              
              const SizedBox(height: 32),
              
              // Title
              Text(
                'Enter Verification Code',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              
              const SizedBox(height: 8),
              
              // Subtitle
              RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: AppTheme.textSecondary,
                  ),
                  children: [
                    const TextSpan(text: 'We have sent a 6-digit code to\n'),
                    TextSpan(
                      text: authController.phoneNumber.value,
                      style: const TextStyle(
                        color: AppTheme.primaryColor,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 40),
              
              // OTP Input
              Pinput(
                controller: otpController,
                focusNode: otpFocusNode,
                length: 6,
                defaultPinTheme: _pinTheme(),
                focusedPinTheme: _focusedPinTheme(),
                submittedPinTheme: _submittedPinTheme(),
                validator: (value) {
                  if (value == null || value.length != 6) {
                    return 'Please enter a 6-digit code';
                  }
                  return null;
                },
                onCompleted: (pin) {
                  _verifyOTP(pin);
                },
                onChanged: (value) {
                  // Auto-verify when 6 digits are entered
                  if (value.length == 6) {
                    _verifyOTP(value);
                  }
                },
              ),
              
              const SizedBox(height: 32),
              
              // Verify Button
              Obx(() => CustomButton(
                text: 'Verify',
                isLoading: authController.isLoading.value,
                onPressed: authController.isLoading.value
                    ? null
                    : () => _verifyOTP(otpController.text.trim()),
              )),
              
              const SizedBox(height: 24),
              
              // Resend Code Section
              Column(
                children: [
                  Text(
                    _canResend
                        ? 'Didn\'t receive the code?'
                        : 'Resend code in $_remainingTime seconds',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: AppTheme.textSecondary,
                    ),
                  ),
                  
                  if (_canResend) ...[
                    const SizedBox(height: 8),
                    TextButton(
                      onPressed: _handleResendCode,
                      child: Text(
                        'Resend Code',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppTheme.primaryColor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              
              const SizedBox(height: 32),
              
              // Troubleshooting
              TextButton(
                onPressed: _showTroubleshootingDialog,
                child: Text(
                  'Having trouble?',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: AppTheme.textSecondary,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
              
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  PinTheme _pinTheme() {
    return PinTheme(
      width: 56,
      height: 56,
      textStyle: Theme.of(context).textTheme.headlineSmall?.copyWith(
        fontWeight: FontWeight.w600,
      ),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.textHint.withOpacity(0.3)),
      ),
    );
  }

  PinTheme _focusedPinTheme() {
    return PinTheme(
      width: 56,
      height: 56,
      textStyle: Theme.of(context).textTheme.headlineSmall?.copyWith(
        fontWeight: FontWeight.w600,
      ),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.primaryColor, width: 2),
      ),
    );
  }

  PinTheme _submittedPinTheme() {
    return PinTheme(
      width: 56,
      height: 56,
      textStyle: Theme.of(context).textTheme.headlineSmall?.copyWith(
        fontWeight: FontWeight.w600,
      ),
      decoration: BoxDecoration(
        color: AppTheme.primaryColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.primaryColor),
      ),
    );
  }

  void _verifyOTP(String otp) {
    if (otp.length == 6) {
      authController.verifyOTP(otp);
    }
  }

  void _handleResendCode() {
    setState(() {
      _remainingTime = 60;
      _canResend = false;
      _startTimer();
    });
    authController.resendOTP();
  }

  void _showTroubleshootingDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Verification Help'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _troubleshootingItem(
              '1. Check your SMS messages',
              'Make sure you have network coverage and can receive SMS.',
            ),
            const SizedBox(height: 12),
            _troubleshootingItem(
              '2. Wait a few minutes',
              'Sometimes there can be a delay in receiving the code.',
            ),
            const SizedBox(height: 12),
            _troubleshootingItem(
              '3. Check your phone number',
              'Make sure you entered the correct phone number.',
            ),
            const SizedBox(height: 12),
            _troubleshootingItem(
              '4. Try resending the code',
              'You can request a new code after the timer expires.',
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Got it'),
          ),
        ],
      ),
    );
  }

  Widget _troubleshootingItem(String title, String description) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          description,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: AppTheme.textSecondary,
          ),
        ),
      ],
    );
  }
}