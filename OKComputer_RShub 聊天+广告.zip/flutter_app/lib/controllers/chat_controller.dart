import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:audioplayers/audioplayers.dart';

import '../models/message_model.dart';
import '../models/chat_model.dart';
import '../models/user_model.dart';
import '../services/firebase_service.dart';
import '../services/ad_service.dart';
import '../config/app_config.dart';
import '../utils/helpers.dart';

class ChatController extends GetxController {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final AudioPlayer _audioPlayer = AudioPlayer();
  
  // Observables
  final RxList<MessageModel> messages = <MessageModel>[].obs;
  final RxList<ChatModel> chats = <ChatModel>[].obs;
  final Rx<ChatModel?> currentChat = Rx<ChatModel?>(null);
  final Rx<UserModel?> chatUser = Rx<UserModel?>(null);
  final RxBool isLoading = false.obs;
  final RxBool isSending = false.obs;
  final RxBool isTyping = false.obs;
  final RxString replyToMessageId = ''.obs;
  final Rx<MessageModel?> replyToMessage = Rx<MessageModel?>(null);
  
  // Stream subscriptions
  StreamSubscription? _messagesSubscription;
  StreamSubscription? _chatsSubscription;
  StreamSubscription? _typingSubscription;
  
  // Counters for ad frequency
  final Map<String, int> _messageCounters = {};
  final Map<String, DateTime> _lastAdTime = {};
  
  @override
  void onClose() {
    _messagesSubscription?.cancel();
    _chatsSubscription?.cancel();
    _typingSubscription?.cancel();
    _audioPlayer.dispose();
    super.onClose();
  }
  
  // Load user's chats
  void loadUserChats() {
    final userId = _auth.currentUser?.uid;
    if (userId == null) return;
    
    _chatsSubscription?.cancel();
    _chatsSubscription = _firestore
        .collection('chats')
        .where('participants', arrayContains: userId)
        .orderBy('lastMessageTime', descending: true)
        .snapshots()
        .listen((snapshot) {
          chats.value = snapshot.docs
              .map((doc) => ChatModel.fromFirestore(doc))
              .toList();
        });
  }
  
  // Load chat messages
  void loadChatMessages(String chatId) {
    _messagesSubscription?.cancel();
    _messagesSubscription = _firestore
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .limit(AppConfig.messageLoadLimit)
        .snapshots()
        .listen((snapshot) {
          messages.value = snapshot.docs
              .map((doc) => MessageModel.fromFirestore(doc))
              .toList();
          
          // Mark messages as delivered and seen
          _updateMessageStatus(chatId);
        });
  }
  
  // Load specific chat
  Future<void> loadChat(String chatId) async {
    isLoading.value = true;
    
    try {
      final chatDoc = await _firestore.collection('chats').doc(chatId).get();
      if (chatDoc.exists) {
        currentChat.value = ChatModel.fromFirestore(chatDoc);
        loadChatMessages(chatId);
        
        // Load chat user info if individual chat
        if (currentChat.value?.isIndividual ?? false) {
          await _loadChatUser(chatId);
        }
        
        // Initialize ad tracking
        _initializeAdTracking(chatId);
      }
    } catch (e) {
      print('Error loading chat: $e');
      Helpers.showErrorSnackBar('Failed to load chat');
    } finally {
      isLoading.value = false;
    }
  }
  
  Future<void> _loadChatUser(String chatId) async {
    final userId = _auth.currentUser?.uid;
    if (userId == null) return;
    
    try {
      final participants = currentChat.value?.participants ?? [];
      final otherUserId = participants.firstWhere((id) => id != userId);
      
      final userDoc = await _firestore.collection('users').doc(otherUserId).get();
      if (userDoc.exists) {
        chatUser.value = UserModel.fromFirestore(userDoc);
      }
    } catch (e) {
      print('Error loading chat user: $e');
    }
  }
  
  void _initializeAdTracking(String chatId) {
    if (!_messageCounters.containsKey(chatId)) {
      _messageCounters[chatId] = 0;
      _lastAdTime[chatId] = DateTime.now();
    }
  }
  
  // Send message
  Future<void> sendMessage({
    required String chatId,
    required String content,
    String type = 'text',
    Map<String, dynamic>? metadata,
    String? replyTo,
  }) async {
    if (content.trim().isEmpty) return;
    
    isSending.value = true;
    
    try {
      final userId = _auth.currentUser?.uid;
      if (userId == null) return;
      
      // Check if ad should be shown
      final shouldShowAd = await _shouldShowAd(chatId, type);
      
      // Create message
      final message = MessageModel(
        messageId: _firestore.collection('chats').doc(chatId).collection('messages').doc().id,
        chatId: chatId,
        senderId: userId,
        content: content,
        type: type,
        timestamp: Timestamp.now(),
        replyTo: replyTo,
        metadata: metadata,
        adData: shouldShowAd ? _createAdData() : null,
      );
      
      // Save message
      await _firestore
          .collection('chats')
          .doc(chatId)
          .collection('messages')
          .doc(message.messageId)
          .set(message.toMap());
      
      // Update chat last message
      await _updateChatLastMessage(chatId, message);
      
      // Show ad if needed
      if (shouldShowAd) {
        _showInterstitialAd(chatId);
      }
      
      // Clear reply
      replyToMessageId.value = '';
      replyToMessage.value = null;
      
      // Play send sound
      _playMessageSound();
      
    } catch (e) {
      print('Error sending message: $e');
      Helpers.showErrorSnackBar('Failed to send message');
    } finally {
      isSending.value = false;
    }
  }
  
  // Send media message
  Future<void> sendMediaMessage({
    required String chatId,
    required XFile file,
    String type = 'image',
  }) async {
    isSending.value = true;
    
    try {
      // Upload file
      final fileUrl = await FirebaseService.instance.uploadMediaFile(file, type);
      if (fileUrl == null) {
        throw Exception('Failed to upload file');
      }
      
      // Get file metadata
      final metadata = await _getFileMetadata(file, type);
      
      // Send message
      await sendMessage(
        chatId: chatId,
        content: fileUrl,
        type: type,
        metadata: metadata,
      );
      
    } catch (e) {
      print('Error sending media: $e');
      Helpers.showErrorSnackBar('Failed to send media');
    } finally {
      isSending.value = false;
    }
  }
  
  Future<Map<String, dynamic>> _getFileMetadata(XFile file, String type) async {
    final metadata = {
      'fileName': file.name,
      'fileUrl': file.path,
    };
    
    // Get file size
    try {
      final fileBytes = await file.readAsBytes();
      metadata['fileSize'] = _formatFileSize(fileBytes.length);
    } catch (e) {
      print('Error getting file size: $e');
    }
    
    // Type-specific metadata
    switch (type) {
      case 'image':
      case 'video':
        // Add dimension extraction if needed
        break;
      case 'audio':
        // Add duration extraction if needed
        break;
    }
    
    return metadata;
  }
  
  String _formatFileSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }
  
  // Ad-related functions
  Future<bool> _shouldShowAd(String chatId, String messageType) async {
    if (messageType != 'text') return false; // Only show ads for text messages
    
    final chat = currentChat.value;
    if (chat == null) return false;
    
    final userId = _auth.currentUser?.uid;
    if (userId == null) return false;
    
    // Check if ads are enabled for this chat
    final adsEnabled = chat.adsEnabledForUser(userId);
    if (!adsEnabled) return false;
    
    // Check message counter
    final messageCount = _messageCounters[chatId] ?? 0;
    final frequency = chat.getAdFrequency(userId);
    
    if (messageCount >= frequency) {
      _messageCounters[chatId] = 0;
      return true;
    }
    
    _messageCounters[chatId] = messageCount + 1;
    return false;
  }
  
  Map<String, dynamic> _createAdData() {
    return {
      'isAdMessage': true,
      'adType': 'interstitial',
      'adRevenue': 0.001, // Example revenue per ad view
      'timestamp': Timestamp.now(),
    };
  }
  
  void _showInterstitialAd(String chatId) {
    AdService.instance.showInterstitialAd(
      onAdClosed: () {
        // Ad closed, continue normal chat
        print('Ad closed for chat: $chatId');
      },
      onAdFailed: () {
        // Ad failed to load, continue without ad
        print('Ad failed for chat: $chatId');
      },
    );
  }
  
  // Update chat last message
  Future<void> _updateChatLastMessage(String chatId, MessageModel message) async {
    try {
      await _firestore.collection('chats').doc(chatId).update({
        'lastMessage': {
          'messageId': message.messageId,
          'senderId': message.senderId,
          'content': message.content,
          'type': message.type,
          'timestamp': message.timestamp,
        },
        'lastMessageTime': message.timestamp,
      });
    } catch (e) {
      print('Error updating last message: $e');
    }
  }
  
  // Update message status (delivered, seen)
  Future<void> _updateMessageStatus(String chatId) async {
    final userId = _auth.currentUser?.uid;
    if (userId == null) return;
    
    try {
      final batch = _firestore.batch();
      
      for (final message in messages) {
        if (!message.isSentBy(userId) && !message.isSeenBy(userId)) {
          final messageRef = _firestore
              .collection('chats')
              .doc(chatId)
              .collection('messages')
              .doc(message.messageId);
          
          // Mark as delivered
          if (!message.isDeliveredTo(userId)) {
            batch.update(messageRef, {
              'deliveredTo': FieldValue.arrayUnion([userId]),
            });
          }
          
          // Mark as seen (for visible messages)
          batch.update(messageRef, {
            'seenBy': FieldValue.arrayUnion([userId]),
          });
        }
      }
      
      await batch.commit();
    } catch (e) {
      print('Error updating message status: $e');
    }
  }
  
  // Delete message
  Future<void> deleteMessage(String chatId, String messageId, {bool deleteForEveryone = false}) async {
    try {
      final messageRef = _firestore
          .collection('chats')
          .doc(chatId)
          .collection('messages')
          .doc(messageId);
      
      if (deleteForEveryone) {
        await messageRef.update({
          'isDeleted': true,
          'content': 'This message was deleted',
          'type': 'text',
          'metadata': null,
        });
      } else {
        // Just mark as deleted for current user
        final userId = _auth.currentUser?.uid;
        if (userId != null) {
          await messageRef.update({
            'deletedFor': FieldValue.arrayUnion([userId]),
          });
        }
      }
    } catch (e) {
      print('Error deleting message: $e');
      Helpers.showErrorSnackBar('Failed to delete message');
    }
  }
  
  // Edit message
  Future<void> editMessage(String chatId, String messageId, String newContent) async {
    try {
      await _firestore
          .collection('chats')
          .doc(chatId)
          .collection('messages')
          .doc(messageId)
          .update({
        'content': newContent,
        'isEdited': true,
        'editedAt': Timestamp.now(),
      });
    } catch (e) {
      print('Error editing message: $e');
      Helpers.showErrorSnackBar('Failed to edit message');
    }
  }
  
  // Typing indicators
  void startTyping(String chatId) {
    if (isTyping.value) return;
    
    isTyping.value = true;
    final userId = _auth.currentUser?.uid;
    if (userId != null) {
      _firestore.collection('chats').doc(chatId).update({
        'typingUsers': FieldValue.arrayUnion([userId]),
      });
    }
  }
  
  void stopTyping(String chatId) {
    if (!isTyping.value) return;
    
    isTyping.value = false;
    final userId = _auth.currentUser?.uid;
    if (userId != null) {
      _firestore.collection('chats').doc(chatId).update({
        'typingUsers': FieldValue.arrayRemove([userId]),
      });
    }
  }
  
  // Reply to message
  void setReplyToMessage(MessageModel message) {
    replyToMessageId.value = message.messageId;
    replyToMessage.value = message;
  }
  
  void clearReplyToMessage() {
    replyToMessageId.value = '';
    replyToMessage.value = null;
  }
  
  // Play message sound
  void _playMessageSound() async {
    try {
      // You can add a custom sound file
      // await _audioPlayer.play(AssetSource('sounds/message_sent.mp3'));
    } catch (e) {
      print('Error playing sound: $e');
    }
  }
  
  // Create or get individual chat
  Future<String?> createIndividualChat(String otherUserId) async {
    try {
      final userId = _auth.currentUser?.uid;
      if (userId == null) return null;
      
      // Check if chat already exists
      final existingChatQuery = await _firestore
          .collection('chats')
          .where('type', isEqualTo: 'individual')
          .where('participants', arrayContains: userId)
          .get();
      
      for (final doc in existingChatQuery.docs) {
        final chat = ChatModel.fromFirestore(doc);
        if (chat.participants.contains(otherUserId)) {
          return chat.chatId;
        }
      }
      
      // Create new chat
      final chatId = _firestore.collection('chats').doc().id;
      final newChat = ChatModel(
        chatId: chatId,
        type: 'individual',
        participants: [userId, otherUserId],
        lastMessage: {},
        lastMessageTime: Timestamp.now(),
        unreadCount: {userId: 0, otherUserId: 0},
      );
      
      await _firestore.collection('chats').doc(chatId).set(newChat.toMap());
      return chatId;
      
    } catch (e) {
      print('Error creating chat: $e');
      return null;
    }
  }
}