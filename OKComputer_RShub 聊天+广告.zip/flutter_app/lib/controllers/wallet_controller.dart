import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/transaction_model.dart';
import '../models/withdrawal_model.dart';
import '../config/app_config.dart';
import '../utils/helpers.dart';

class WalletController extends GetxController {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  
  // Observables
  final RxDouble totalEarning = 0.0.obs;
  final RxDouble todayEarning = 0.0.obs;
  final RxDouble walletBalance = 0.0.obs;
  final RxDouble pendingBalance = 0.0.obs;
  final RxList<TransactionModel> transactions = <TransactionModel>[].obs;
  final RxList<WithdrawalModel> withdrawalHistory = <WithdrawalModel>[].obs;
  final RxBool isLoading = false.obs;
  final RxBool isWithdrawing = false.obs;
  
  // Stream subscriptions
  StreamSubscription? _walletSubscription;
  StreamSubscription? _transactionsSubscription;
  
  @override
  void onInit() {
    super.onInit();
    loadWalletData();
  }
  
  @override
  void onClose() {
    _walletSubscription?.cancel();
    _transactionsSubscription?.cancel();
    super.onClose();
  }
  
  // Load wallet data
  void loadWalletData() {
    final userId = _auth.currentUser?.uid;
    if (userId == null) return;
    
    // Load wallet balance and earnings
    _walletSubscription?.cancel();
    _walletSubscription = _firestore
        .collection('users')
        .doc(userId)
        .snapshots()
        .listen((snapshot) {
          if (snapshot.exists) {
            final data = snapshot.data()!;
            totalEarning.value = (data['totalEarning'] ?? 0.0).toDouble();
            todayEarning.value = (data['todayEarning'] ?? 0.0).toDouble();
            walletBalance.value = (data['walletBalance'] ?? 0.0).toDouble();
          }
        });
    
    // Load transactions
    loadTransactions();
    
    // Load withdrawal history
    loadWithdrawalHistory();
  }
  
  // Load transaction history
  void loadTransactions() {
    final userId = _auth.currentUser?.uid;
    if (userId == null) return;
    
    _transactionsSubscription?.cancel();
    _transactionsSubscription = _firestore
        .collection('transactions')
        .where('userId', isEqualTo: userId)
        .orderBy('timestamp', descending: true)
        .limit(50)
        .snapshots()
        .listen((snapshot) {
          transactions.value = snapshot.docs
              .map((doc) => TransactionModel.fromFirestore(doc))
              .toList();
        });
  }
  
  // Load withdrawal history
  Future<void> loadWithdrawalHistory() async {
    final userId = _auth.currentUser?.uid;
    if (userId == null) return;
    
    try {
      final snapshot = await _firestore
          .collection('withdrawals')
          .where('userId', isEqualTo: userId)
          .orderBy('requestedAt', descending: true)
          .limit(20)
          .get();
      
      withdrawalHistory.value = snapshot.docs
          .map((doc) => WithdrawalModel.fromFirestore(doc))
          .toList();
    } catch (e) {
      print('Error loading withdrawal history: $e');
    }
  }
  
  // Add earning from ad views
  Future<void> addAdEarning({
    required String adType,
    required double amount,
    required String source, // 'group_ad', 'chat_ad', 'file_download_ad'
    String? chatId,
    String? groupId,
    String? messageId,
  }) async {
    final userId = _auth.currentUser?.uid;
    if (userId == null) return;
    
    try {
      // Create transaction record
      final transaction = TransactionModel(
        transactionId: _firestore.collection('transactions').doc().id,
        userId: userId,
        type: 'earning',
        amount: amount,
        source: source,
        description: 'Earning from $adType ad view',
        status: 'completed',
        timestamp: Timestamp.now(),
        metadata: {
          'adType': adType,
          if (chatId != null) 'chatId': chatId,
          if (groupId != null) 'groupId': groupId,
          if (messageId != null) 'messageId': messageId,
        },
      );
      
      // Save transaction
      await _firestore
          .collection('transactions')
          .doc(transaction.transactionId)
          .set(transaction.toMap());
      
      // Update user wallet
      await _firestore.collection('users').doc(userId).update({
        'walletBalance': FieldValue.increment(amount),
        'totalEarning': FieldValue.increment(amount),
        'todayEarning': FieldValue.increment(amount),
        'lastEarningAt': Timestamp.now(),
      });
      
      // Update daily earning record
      await _updateDailyEarning(userId, amount);
      
    } catch (e) {
      print('Error adding ad earning: $e');
    }
  }
  
  // Update daily earning record
  Future<void> _updateDailyEarning(String userId, double amount) async {
    try {
      final today = DateTime.now();
      final dateKey = '${today.year}-${today.month}-${today.day}';
      
      final dailyEarningRef = _firestore
          .collection('daily_earnings')
          .doc('$userId-$dateKey');
      
      await dailyEarningRef.set({
        'userId': userId,
        'date': dateKey,
        'amount': FieldValue.increment(amount),
        'updatedAt': Timestamp.now(),
      }, SetOptions(merge: true));
    } catch (e) {
      print('Error updating daily earning: $e');
    }
  }
  
  // Process withdrawal request
  Future<void> requestWithdrawal({
    required double amount,
    required String paymentMethod,
    required String accountNumber,
    String? accountName,
  }) async {
    if (amount <= 0) {
      Helpers.showErrorSnackBar('Invalid withdrawal amount');
      return;
    }
    
    if (amount > walletBalance.value) {
      Helpers.showErrorSnackBar('Insufficient balance');
      return;
    }
    
    if (amount < AppConfig.minimumWithdrawal) {
      Helpers.showErrorSnackBar(
        'Minimum withdrawal amount is ${AppConfig.minimumWithdrawal}',
      );
      return;
    }
    
    isWithdrawing.value = true;
    
    try {
      final userId = _auth.currentUser?.uid;
      if (userId == null) {
        Helpers.showErrorSnackBar('User not authenticated');
        return;
      }
      
      // Create withdrawal request
      final withdrawal = WithdrawalModel(
        withdrawalId: _firestore.collection('withdrawals').doc().id,
        userId: userId,
        amount: amount,
        paymentMethod: paymentMethod,
        accountNumber: accountNumber,
        accountName: accountName,
        status: 'pending',
        requestedAt: Timestamp.now(),
      );
      
      // Save withdrawal request
      await _firestore
          .collection('withdrawals')
          .doc(withdrawal.withdrawalId)
          .set(withdrawal.toMap());
      
      // Deduct from wallet balance
      await _firestore.collection('users').doc(userId).update({
        'walletBalance': FieldValue.increment(-amount),
        'pendingBalance': FieldValue.increment(amount),
      });
      
      // Create transaction record
      final transaction = TransactionModel(
        transactionId: _firestore.collection('transactions').doc().id,
        userId: userId,
        type: 'withdrawal',
        amount: -amount,
        source: 'withdrawal_request',
        description: 'Withdrawal request to $paymentMethod',
        status: 'pending',
        timestamp: Timestamp.now(),
        metadata: {
          'withdrawalId': withdrawal.withdrawalId,
          'paymentMethod': paymentMethod,
          'accountNumber': accountNumber,
        },
      );
      
      await _firestore
          .collection('transactions')
          .doc(transaction.transactionId)
          .set(transaction.toMap());
      
      // Send notification to admin
      await _notifyAdminOfWithdrawal(withdrawal);
      
      Helpers.showSuccessSnackBar('Withdrawal request submitted successfully');
      
      // Reload data
      loadWalletData();
      loadWithdrawalHistory();
      
    } catch (e) {
      print('Error processing withdrawal: $e');
      Helpers.showErrorSnackBar('Failed to process withdrawal request');
    } finally {
      isWithdrawing.value = false;
    }
  }
  
  // Notify admin of new withdrawal request
  Future<void> _notifyAdminOfWithdrawal(WithdrawalModel withdrawal) async {
    try {
      await _firestore.collection('admin_notifications').add({
        'type': 'withdrawal_request',
        'withdrawalId': withdrawal.withdrawalId,
        'userId': withdrawal.userId,
        'amount': withdrawal.amount,
        'paymentMethod': withdrawal.paymentMethod,
        'status': 'pending',
        'createdAt': Timestamp.now(),
      });
    } catch (e) {
      print('Error notifying admin: $e');
    }
  }
  
  // Calculate total earnings breakdown
  Map<String, double> getEarningsBreakdown() {
    final breakdown = <String, double>{
      'group_ads': 0.0,
      'chat_ads': 0.0,
      'file_download_ads': 0.0,
      'daily_rewards': 0.0,
      'referral_earnings': 0.0,
    };
    
    for (final transaction in transactions) {
      if (transaction.type == 'earning' && transaction.status == 'completed') {
        final source = transaction.source;
        breakdown[source] = (breakdown[source] ?? 0.0) + transaction.amount;
      }
    }
    
    return breakdown;
  }
  
  // Get monthly earning statistics
  Future<Map<String, double>> getMonthlyEarnings() async {
    final userId = _auth.currentUser?.uid;
    if (userId == null) return {};
    
    final monthlyData = <String, double>{};
    
    try {
      final now = DateTime.now();
      final sixMonthsAgo = DateTime(now.year, now.month - 6, now.day);
      
      final snapshot = await _firestore
          .collection('transactions')
          .where('userId', isEqualTo: userId)
          .where('type', isEqualTo: 'earning')
          .where('timestamp', isGreaterThan: Timestamp.fromDate(sixMonthsAgo))
          .get();
      
      for (final doc in snapshot.docs) {
        final transaction = TransactionModel.fromFirestore(doc);
        final date = transaction.timestamp.toDate();
        final monthKey = '${date.year}-${date.month.toString().padLeft(2, '0')}';
        
        monthlyData[monthKey] = (monthlyData[monthKey] ?? 0.0) + transaction.amount;
      }
    } catch (e) {
      print('Error getting monthly earnings: $e');
    }
    
    return monthlyData;
  }
  
  // Check if user can withdraw
  bool get canWithdraw {
    return walletBalance.value >= AppConfig.minimumWithdrawal;
  }
  
  // Get withdrawal fee (if any)
  double getWithdrawalFee(double amount) {
    // You can implement different fee structures here
    return 0.0; // No fee for now
  }
  
  // Calculate net withdrawal amount
  double getNetWithdrawalAmount(double amount) {
    return amount - getWithdrawalFee(amount);
  }
  
  // Validate payment method details
  bool validatePaymentMethod(String method, Map<String, String> details) {
    switch (method) {
      case 'bKash':
      case 'Nagad':
      case 'Rocket':
        final accountNumber = details['accountNumber'] ?? '';
        return accountNumber.length == 11 && accountNumber.startsWith('01');
      case 'Bank Transfer':
        return details['accountNumber']?.isNotEmpty ?? false;
      default:
        return false;
    }
  }
  
  // Get user's earning rank
  Future<int?> getUserRank() async {
    final userId = _auth.currentUser?.uid;
    if (userId == null) return null;
    
    try {
      // This would require a cloud function or aggregated data
      // For now, return null
      return null;
    } catch (e) {
      print('Error getting user rank: $e');
      return null;
    }
  }
  
  // Get referral earnings
  Future<double> getReferralEarnings() async {
    final userId = _auth.currentUser?.uid;
    if (userId == null) return 0.0;
    
    try {
      final snapshot = await _firestore
          .collection('transactions')
          .where('userId', isEqualTo: userId)
          .where('source', isEqualTo: 'referral')
          .where('status', isEqualTo: 'completed')
          .get();
      
      double total = 0.0;
      for (final doc in snapshot.docs) {
        final transaction = TransactionModel.fromFirestore(doc);
        total += transaction.amount;
      }
      
      return total;
    } catch (e) {
      print('Error getting referral earnings: $e');
      return 0.0;
    }
  }
}