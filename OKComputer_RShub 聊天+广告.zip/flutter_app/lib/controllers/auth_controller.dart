import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get_storage/get_storage.dart';
import 'package:flutter/material.dart';

import '../services/firebase_service.dart';
import '../models/user_model.dart';
import '../routes/app_routes.dart';
import '../utils/helpers.dart';

class AuthController extends GetxController {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final GetStorage _storage = GetStorage();
  
  // Observables
  final Rx<User?> firebaseUser = Rx<User?>(null);
  final Rx<UserModel?> currentUser = Rx<UserModel?>(null);
  final RxBool isLoading = false.obs;
  final RxString verificationId = ''.obs;
  final RxString phoneNumber = ''.obs;
  
  // Getters
  bool get isLoggedIn => firebaseUser.value != null;
  String? get currentUserId => firebaseUser.value?.uid;
  
  @override
  void onInit() {
    super.onInit();
    firebaseUser.bindStream(_auth.authStateChanges());
    ever(firebaseUser, _handleAuthStateChanged);
  }
  
  void _handleAuthStateChanged(User? user) async {
    if (user != null) {
      await _loadUserData(user.uid);
      _checkUserRoute();
    }
  }
  
  Future<void> _loadUserData(String uid) async {
    try {
      final userDoc = await _firestore.collection('users').doc(uid).get();
      if (userDoc.exists) {
        currentUser.value = UserModel.fromFirestore(userDoc);
        _storage.write('user_data', userDoc.data());
      }
    } catch (e) {
      print('Error loading user data: $e');
    }
  }
  
  void _checkUserRoute() {
    final bool isProfileComplete = _storage.read('is_profile_complete') ?? false;
    
    if (!isProfileComplete) {
      Get.offAllNamed(Routes.PROFILE_SETUP);
    } else {
      Get.offAllNamed(Routes.HOME);
    }
  }
  
  // Phone Authentication
  Future<void> verifyPhoneNumber(String phoneNumber, {bool isLogin = true}) async {
    isLoading.value = true;
    this.phoneNumber.value = phoneNumber;
    
    try {
      await _auth.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        timeout: const Duration(seconds: 60),
        verificationCompleted: (PhoneAuthCredential credential) async {
          await _auth.signInWithCredential(credential);
        },
        verificationFailed: (FirebaseAuthException e) {
          isLoading.value = false;
          Helpers.showErrorSnackBar('Verification failed: ${e.message}');
        },
        codeSent: (String verificationId, int? resendToken) {
          isLoading.value = false;
          this.verificationId.value = verificationId;
          Get.toNamed(Routes.OTP);
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          isLoading.value = false;
          this.verificationId.value = verificationId;
        },
      );
    } catch (e) {
      isLoading.value = false;
      Helpers.showErrorSnackBar('Error: ${e.toString()}');
    }
  }
  
  // Verify OTP
  Future<void> verifyOTP(String otp) async {
    isLoading.value = true;
    
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: verificationId.value,
        smsCode: otp,
      );
      
      final userCredential = await _auth.signInWithCredential(credential);
      
      if (userCredential.user != null) {
        await _handleUserLogin(userCredential.user!);
      }
    } catch (e) {
      isLoading.value = false;
      Helpers.showErrorSnackBar('Invalid OTP. Please try again.');
    }
  }
  
  Future<void> _handleUserLogin(User user) async {
    final userDoc = await _firestore.collection('users').doc(user.uid).get();
    
    if (!userDoc.exists) {
      // New user - create profile
      await _createUserProfile(user);
      Get.offAllNamed(Routes.PROFILE_SETUP);
    } else {
      // Existing user
      await _loadUserData(user.uid);
      _storage.write('is_profile_complete', true);
      Get.offAllNamed(Routes.HOME);
    }
  }
  
  Future<void> _createUserProfile(User user) async {
    final newUser = UserModel(
      uid: user.uid,
      phone: user.phoneNumber ?? phoneNumber.value,
      name: '',
      profileImage: '',
      bio: '',
      onlineStatus: true,
      walletBalance: 0.0,
      totalEarning: 0.0,
      deviceId: await FirebaseService.instance.getDeviceId(),
      createdAt: DateTime.now(),
      isActive: true,
      lastSeen: DateTime.now(),
    );
    
    await _firestore.collection('users').doc(user.uid).set(newUser.toMap());
    currentUser.value = newUser;
  }
  
  // Complete Profile Setup
  Future<void> completeProfileSetup({
    required String name,
    String? profileImage,
    String? bio,
  }) async {
    isLoading.value = true;
    
    try {
      final uid = currentUserId;
      if (uid == null) {
        throw Exception('User not found');
      }
      
      final updateData = {
        'name': name,
        'bio': bio ?? '',
        'profileImage': profileImage ?? '',
        'updatedAt': DateTime.now().toIso8601String(),
      };
      
      await _firestore.collection('users').doc(uid).update(updateData);
      
      // Update local user data
      currentUser.value = currentUser.value?.copyWith(
        name: name,
        bio: bio ?? '',
        profileImage: profileImage ?? '',
      );
      
      _storage.write('is_profile_complete', true);
      await _loadUserData(uid);
      
      Get.offAllNamed(Routes.HOME);
    } catch (e) {
      Helpers.showErrorSnackBar('Failed to complete profile: ${e.toString()}');
    } finally {
      isLoading.value = false;
    }
  }
  
  // Sign Out
  Future<void> signOut() async {
    try {
      await _auth.signOut();
      _storage.erase();
      currentUser.value = null;
      Get.offAllNamed(Routes.LOGIN);
    } catch (e) {
      Helpers.showErrorSnackBar('Failed to sign out: ${e.toString()}');
    }
  }
  
  // Update Online Status
  Future<void> updateOnlineStatus(bool isOnline) async {
    if (currentUserId == null) return;
    
    try {
      await _firestore.collection('users').doc(currentUserId).update({
        'onlineStatus': isOnline,
        'lastSeen': DateTime.now().toIso8601String(),
      });
      
      currentUser.value = currentUser.value?.copyWith(
        onlineStatus: isOnline,
        lastSeen: DateTime.now(),
      );
    } catch (e) {
      print('Error updating online status: $e');
    }
  }
  
  // Check if user exists by phone
  Future<bool> checkUserExists(String phoneNumber) async {
    try {
      final query = await _firestore
          .collection('users')
          .where('phone', isEqualTo: phoneNumber)
          .get();
      
      return query.docs.isNotEmpty;
    } catch (e) {
      print('Error checking user existence: $e');
      return false;
    }
  }
  
  // Resend OTP
  Future<void> resendOTP() async {
    if (phoneNumber.value.isNotEmpty) {
      await verifyPhoneNumber(phoneNumber.value);
    }
  }
}