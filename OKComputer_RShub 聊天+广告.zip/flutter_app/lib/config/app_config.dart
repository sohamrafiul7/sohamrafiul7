class AppConfig {
  // App Info
  static const String appName = 'RShub';
  static const String appVersion = '1.0.0';
  static const String appDescription = 'Real-time chat and earning platform';
  
  // API Configuration
  static const String baseUrl = 'https://api.rshub.com';
  static const String socketUrl = 'wss://socket.rshub.com';
  static const int apiTimeout = 30000; // 30 seconds
  
  // Firebase Configuration
  static const String firebaseStorageBucket = 'rshub-app.appspot.com';
  
  // Ad Configuration
  static const String admobAppId = 'ca-app-pub-xxxxxxxxxxxxxxxx~xxxxxxxxxx';
  static const String facebookAppId = 'xxxxxxxxxxxxxxxx';
  
  // Ad Unit IDs (Test IDs - Replace with production IDs)
  static const String bannerAdUnitId = 'ca-app-pub-3940256099942544/6300978111';
  static const String interstitialAdUnitId = 'ca-app-pub-3940256099942544/1033173712';
  static const String rewardedAdUnitId = 'ca-app-pub-3940256099942544/5224354917';
  
  // Feature Configuration
  static const bool enableVoiceCalls = true;
  static const bool enableVideoCalls = true;
  static const bool enableFileSharing = true;
  static const int maxFileSize = 100; // MB
  static const int maxGroupMembers = 1000;
  
  // Earning Configuration
  static const double groupAdRevenueShare = 0.7; // 70% to user
  static const double fileDownloadRevenueShare = 0.8; // 80% to uploader
  static const double chatAdRevenueShare = 0.6; // 60% to user
  static const double minimumWithdrawal = 100.0; // Minimum withdrawal amount
  static const int dailyAdLimit = 50; // Maximum ads per day
  
  // Ad Frequency Settings
  static const int groupAdFrequencyMessages = 10;
  static const int groupAdFrequencyMinutes = 5;
  static const int chatAdFrequencyMessages = 20;
  
  // Payment Configuration
  static const List<String> supportedPaymentMethods = [
    'bKash',
    'Nagad', 
    'Rocket',
    'Bank Transfer'
  ];
  
  // Cache Configuration
  static const int cacheValidityDays = 7;
  static const int maxCacheSizeMB = 500;
  
  // Notification Configuration
  static const String notificationChannelId = 'rshub_messages';
  static const String notificationChannelName = 'RShub Messages';
  static const String notificationChannelDescription = 'Notifications for new messages';
  
  // Privacy & Security
  static const bool enableEndToEndEncryption = false; // Future feature
  static const int maxLoginAttempts = 5;
  static const int loginLockoutDurationMinutes = 30;
  
  // Performance Configuration
  static const int messageLoadLimit = 50;
  static const int chatListLoadLimit = 20;
  static const int imageCompressionQuality = 80;
  static const int thumbnailSize = 200; // pixels
}