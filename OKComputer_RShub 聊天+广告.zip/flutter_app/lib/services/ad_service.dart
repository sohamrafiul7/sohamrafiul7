import 'package:get/get.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:facebook_audience_network/facebook_audience_network.dart';

import '../config/app_config.dart';
import '../controllers/wallet_controller.dart';
import '../utils/helpers.dart';

class AdService extends GetxService {
  static AdService get instance => Get.find<AdService>();
  
  // Ad instances
  BannerAd? _bannerAd;
  InterstitialAd? _interstitialAd;
  RewardedAd? _rewardedAd;
  
  // State
  final RxBool isInitialized = false.obs;
  final RxBool isBannerAdLoaded = false.obs;
  final RxBool isInterstitialAdLoaded = false.obs;
  final RxBool isRewardedAdLoaded = false.obs;
  
  // Ad counters and tracking
  int _interstitialAdCounter = 0;
  int _rewardedAdCounter = 0;
  DateTime _lastInterstitialAdTime = DateTime.now();
  DateTime _lastRewardedAdTime = DateTime.now();
  
  // Ad configuration
  final int _interstitialAdInterval = 3; // Show every 3rd time
  final Duration _interstitialAdCooldown = const Duration(minutes: 2);
  final Duration _rewardedAdCooldown = const Duration(minutes: 5);
  
  @override
  void onInit() {
    super.onInit();
    initialize();
  }
  
  // Initialize ad services
  Future<void> initialize() async {
    try {
      // Initialize AdMob
      await MobileAds.instance.initialize();
      
      // Initialize Facebook Audience Network
      FacebookAudienceNetwork.init(
        testingId: "37b1da9d-b48c-4103-a393-2e095e734bd6",
        iOSAdvertiserTrackingEnabled: true,
      );
      
      isInitialized.value = true;
      print('Ad services initialized successfully');
      
      // Preload ads
      loadInterstitialAd();
      loadRewardedAd();
      
    } catch (e) {
      print('Error initializing ad services: $e');
      isInitialized.value = false;
    }
  }
  
  // Load banner ad
  Future<void> loadBannerAd() async {
    if (!isInitialized.value) return;
    
    try {
      _bannerAd = BannerAd(
        adUnitId: AppConfig.bannerAdUnitId,
        request: const AdRequest(),
        size: AdSize.banner,
        listener: BannerAdListener(
          onAdLoaded: (ad) {
            print('Banner ad loaded');
            isBannerAdLoaded.value = true;
          },
          onAdFailedToLoad: (ad, error) {
            print('Banner ad failed to load: $error');
            ad.dispose();
            isBannerAdLoaded.value = false;
          },
          onAdOpened: (ad) {
            print('Banner ad opened');
            _trackAdEvent('banner_opened');
          },
          onAdClosed: (ad) {
            print('Banner ad closed');
            _trackAdEvent('banner_closed');
          },
        ),
      );
      
      await _bannerAd!.load();
      
    } catch (e) {
      print('Error loading banner ad: $e');
      isBannerAdLoaded.value = false;
    }
  }
  
  // Load interstitial ad
  Future<void> loadInterstitialAd() async {
    if (!isInitialized.value) return;
    
    try {
      await InterstitialAd.load(
        adUnitId: AppConfig.interstitialAdUnitId,
        request: const AdRequest(),
        adLoadCallback: InterstitialAdLoadCallback(
          onAdLoaded: (ad) {
            print('Interstitial ad loaded');
            _interstitialAd = ad;
            isInterstitialAdLoaded.value = true;
            
            // Set up event listeners
            ad.fullScreenContentCallback = FullScreenContentCallback(
              onAdShowedFullScreenContent: (ad) {
                print('Interstitial ad showed full screen content');
                _trackAdEvent('interstitial_showed');
              },
              onAdDismissedFullScreenContent: (ad) {
                print('Interstitial ad dismissed');
                ad.dispose();
                _interstitialAd = null;
                isInterstitialAdLoaded.value = false;
                _trackAdEvent('interstitial_dismissed');
                
                // Load next ad
                loadInterstitialAd();
              },
              onAdFailedToShowFullScreenContent: (ad, error) {
                print('Interstitial ad failed to show: $error');
                ad.dispose();
                _interstitialAd = null;
                isInterstitialAdLoaded.value = false;
                
                // Load next ad
                loadInterstitialAd();
              },
            );
          },
          onAdFailedToLoad: (error) {
            print('Interstitial ad failed to load: $error');
            isInterstitialAdLoaded.value = false;
            
            // Try Facebook ads as fallback
            _loadFacebookInterstitialAd();
          },
        ),
      );
      
    } catch (e) {
      print('Error loading interstitial ad: $e');
      isInterstitialAdLoaded.value = false;
    }
  }
  
  // Load rewarded ad
  Future<void> loadRewardedAd() async {
    if (!isInitialized.value) return;
    
    try {
      await RewardedAd.load(
        adUnitId: AppConfig.rewardedAdUnitId,
        request: const AdRequest(),
        rewardedAdLoadCallback: RewardedAdLoadCallback(
          onAdLoaded: (ad) {
            print('Rewarded ad loaded');
            _rewardedAd = ad;
            isRewardedAdLoaded.value = true;
            
            // Set up event listeners
            ad.fullScreenContentCallback = FullScreenContentCallback(
              onAdShowedFullScreenContent: (ad) {
                print('Rewarded ad showed full screen content');
                _trackAdEvent('rewarded_showed');
              },
              onAdDismissedFullScreenContent: (ad) {
                print('Rewarded ad dismissed');
                ad.dispose();
                _rewardedAd = null;
                isRewardedAdLoaded.value = false;
                _trackAdEvent('rewarded_dismissed');
                
                // Load next ad
                loadRewardedAd();
              },
              onAdFailedToShowFullScreenContent: (ad, error) {
                print('Rewarded ad failed to show: $error');
                ad.dispose();
                _rewardedAd = null;
                isRewardedAdLoaded.value = false;
                
                // Load next ad
                loadRewardedAd();
              },
            );
          },
          onAdFailedToLoad: (error) {
            print('Rewarded ad failed to load: $error');
            isRewardedAdLoaded.value = false;
            
            // Try Facebook ads as fallback
            _loadFacebookRewardedAd();
          },
        ),
      );
      
    } catch (e) {
      print('Error loading rewarded ad: $e');
      isRewardedAdLoaded.value = false;
    }
  }
  
  // Load Facebook interstitial ad
  Future<void> _loadFacebookInterstitialAd() async {
    try {
      FacebookInterstitialAd.loadInterstitialAd(
        placementId: "YOUR_FB_INTERSTITIAL_PLACEMENT_ID",
        listener: (result, value) {
          if (result == InterstitialAdResult.LOADED) {
            print('Facebook interstitial ad loaded');
            isInterstitialAdLoaded.value = true;
          } else if (result == InterstitialAdResult.ERROR) {
            print('Facebook interstitial ad failed to load: $value');
            isInterstitialAdLoaded.value = false;
          }
        },
      );
    } catch (e) {
      print('Error loading Facebook interstitial ad: $e');
    }
  }
  
  // Load Facebook rewarded ad
  Future<void> _loadFacebookRewardedAd() async {
    try {
      FacebookRewardedVideoAd.loadRewardedVideoAd(
        placementId: "YOUR_FB_REWARDED_PLACEMENT_ID",
        listener: (result, value) {
          if (result == RewardedVideoAdResult.LOADED) {
            print('Facebook rewarded ad loaded');
            isRewardedAdLoaded.value = true;
          } else if (result == RewardedVideoAdResult.ERROR) {
            print('Facebook rewarded ad failed to load: $value');
            isRewardedAdLoaded.value = false;
          }
        },
      );
    } catch (e) {
      print('Error loading Facebook rewarded ad: $e');
    }
  }
  
  // Show banner ad widget
  Widget getBannerAdWidget() {
    if (!isInitialized.value || !isBannerAdLoaded.value) {
      return const SizedBox.shrink();
    }
    
    return Container(
      height: 50,
      margin: const EdgeInsets.only(bottom: 8),
      child: AdWidget(ad: _bannerAd!),
    );
  }
  
  // Show interstitial ad
  Future<void> showInterstitialAd({
    Function()? onAdClosed,
    Function()? onAdFailed,
    bool forceShow = false,
  }) async {
    // Check if we should show ad based on frequency
    if (!forceShow && !_shouldShowInterstitialAd()) {
      onAdClosed?.call();
      return;
    }
    
    if (!isInterstitialAdLoaded.value) {
      print('Interstitial ad not loaded');
      onAdFailed?.call();
      return;
    }
    
    try {
      await _interstitialAd!.show();
      _lastInterstitialAdTime = DateTime.now();
      _interstitialAdCounter = 0;
      
      // Give reward for viewing ad
      await _rewardAdView('interstitial');
      
      onAdClosed?.call();
      
    } catch (e) {
      print('Error showing interstitial ad: $e');
      onAdFailed?.call();
      
      // Try Facebook ad as fallback
      _showFacebookInterstitialAd(onAdClosed: onAdClosed, onAdFailed: onAdFailed);
    }
  }
  
  // Show rewarded ad
  Future<void> showRewardedAd({
    required Function() onRewardEarned,
    Function()? onAdClosed,
    Function()? onAdFailed,
  }) async {
    if (!isRewardedAdLoaded.value) {
      print('Rewarded ad not loaded');
      onAdFailed?.call();
      return;
    }
    
    if (!_shouldShowRewardedAd()) {
      Helpers.showInfoSnackBar('Please wait before watching another ad');
      onAdFailed?.call();
      return;
    }
    
    try {
      await _rewardedAd!.show(
        onUserEarnedReward: (ad, reward) {
          print('User earned reward: ${reward.amount} ${reward.type}');
          _rewardAdView('rewarded');
          onRewardEarned();
        },
      );
      
      _lastRewardedAdTime = DateTime.now();
      _rewardedAdCounter = 0;
      
      onAdClosed?.call();
      
    } catch (e) {
      print('Error showing rewarded ad: $e');
      onAdFailed?.call();
      
      // Try Facebook ad as fallback
      _showFacebookRewardedAd(
        onRewardEarned: onRewardEarned,
        onAdClosed: onAdClosed,
        onAdFailed: onAdFailed,
      );
    }
  }
  
  // Show Facebook interstitial ad
  void _showFacebookInterstitialAd({
    Function()? onAdClosed,
    Function()? onAdFailed,
  }) {
    try {
      FacebookInterstitialAd.showInterstitialAd();
      _rewardAdView('interstitial');
      onAdClosed?.call();
    } catch (e) {
      print('Error showing Facebook interstitial ad: $e');
      onAdFailed?.call();
    }
  }
  
  // Show Facebook rewarded ad
  void _showFacebookRewardedAd({
    required Function() onRewardEarned,
    Function()? onAdClosed,
    Function()? onAdFailed,
  }) {
    try {
      FacebookRewardedVideoAd.showRewardedVideoAd();
      _rewardAdView('rewarded');
      onRewardEarned();
      onAdClosed?.call();
    } catch (e) {
      print('Error showing Facebook rewarded ad: $e');
      onAdFailed?.call();
    }
  }
  
  // Check if we should show interstitial ad
  bool _shouldShowInterstitialAd() {
    _interstitialAdCounter++;
    
    // Check frequency
    if (_interstitialAdCounter < _interstitialAdInterval) {
      return false;
    }
    
    // Check cooldown
    final timeSinceLastAd = DateTime.now().difference(_lastInterstitialAdTime);
    if (timeSinceLastAd < _interstitialAdCooldown) {
      return false;
    }
    
    return true;
  }
  
  // Check if we should show rewarded ad
  bool _shouldShowRewardedAd() {
    _rewardedAdCounter++;
    
    // Check cooldown
    final timeSinceLastAd = DateTime.now().difference(_lastRewardedAdTime);
    if (timeSinceLastAd < _rewardedAdCooldown) {
      return false;
    }
    
    return true;
  }
  
  // Reward user for ad view
  Future<void> _rewardAdView(String adType) async {
    try {
      final walletController = Get.find<WalletController>();
      
      // Different rewards for different ad types
      double rewardAmount = 0.0;
      String source = '';
      
      switch (adType) {
        case 'interstitial':
          rewardAmount = 0.001; // $0.001 for interstitial
          source = 'chat_ad';
          break;
        case 'rewarded':
          rewardAmount = 0.005; // $0.005 for rewarded
          source = 'daily_reward';
          break;
        case 'banner':
          rewardAmount = 0.0005; // $0.0005 for banner
          source = 'group_ad';
          break;
      }
      
      if (rewardAmount > 0) {
        await walletController.addAdEarning(
          adType: adType,
          amount: rewardAmount,
          source: source,
        );
        
        print('Rewarded user with $rewardAmount for $adType ad view');
      }
      
    } catch (e) {
      print('Error rewarding ad view: $e');
    }
  }
  
  // Track ad events for analytics
  void _trackAdEvent(String event) {
    try {
      // You can integrate with analytics services here
      print('Ad event: $event');
    } catch (e) {
      print('Error tracking ad event: $e');
    }
  }
  
  // Get ad availability status
  Map<String, bool> getAdAvailability() {
    return {
      'banner': isBannerAdLoaded.value,
      'interstitial': isInterstitialAdLoaded.value,
      'rewarded': isRewardedAdLoaded.value,
    };
  }
  
  // Show daily reward ad
  Future<void> showDailyRewardAd({
    required Function() onRewardEarned,
    Function()? onAdClosed,
    Function()? onAdFailed,
  }) async {
    await showRewardedAd(
      onRewardEarned: () async {
        // Give additional daily reward
        try {
          final walletController = Get.find<WalletController>();
          await walletController.addAdEarning(
            adType: 'daily_reward',
            amount: 0.01, // $0.01 daily reward
            source: 'daily_reward',
          );
          onRewardEarned();
        } catch (e) {
          print('Error giving daily reward: $e');
        }
      },
      onAdClosed: onAdClosed,
      onAdFailed: onAdFailed,
    );
  }
  
  // Show file download ad
  Future<void> showFileDownloadAd({
    required String fileId,
    required Function() onAdCompleted,
    Function()? onAdFailed,
  }) async {
    await showRewardedAd(
      onRewardEarned: () async {
        // Give file download reward
        try {
          final walletController = Get.find<WalletController>();
          await walletController.addAdEarning(
            adType: 'file_download',
            amount: 0.002, // $0.002 for file download
            source: 'file_download_ad',
          );
          onAdCompleted();
        } catch (e) {
          print('Error giving file download reward: $e');
        }
      },
      onAdClosed: () {},
      onAdFailed: onAdFailed,
    );
  }
  
  // Dispose ads
  void disposeAds() {
    _bannerAd?.dispose();
    _interstitialAd?.dispose();
    _rewardedAd?.dispose();
  }
}