# RShub - Real-Time Chat & Earning Platform

A comprehensive cross-platform mobile application built with Flutter that combines real-time messaging with ad-based earning features.

## 🚀 Features

### Core Communication
- **1-to-1 Chat**: Real-time text, image, video, audio, and document messaging
- **Group Chat**: Create and manage groups with admin controls
- **Voice/Video Calls**: Optional calling functionality
- **Real-time Features**: Typing indicators, seen status, online/offline status

### Earning System
- **Group Ads**: Revenue sharing between group owners and app
- **File Download Ads**: Earn from media downloads
- **Chat Ads**: Personal chat advertising revenue
- **Daily Rewards**: Regular earning opportunities
- **Anti-Fraud Protection**: VPN detection and suspicious activity monitoring

### Wallet & Payments
- **Earnings Dashboard**: Track total and daily earnings
- **Withdrawal System**: Multiple payment methods (bKash, Nagad, Rocket)
- **Transaction History**: Complete earning and withdrawal records

## 🛠 Technology Stack

### Frontend
- **Flutter 3+**: Cross-platform mobile framework
- **State Management**: GetX/Riverpod
- **Real-time**: Firebase/WebSocket
- **Ads**: AdMob + Facebook Audience Network

### Backend Options
1. **Firebase Stack**:
   - Firestore Database
   - Cloud Functions
   - Firebase Authentication
   - Firebase Storage

2. **Node.js Stack**:
   - Express.js Framework
   - MongoDB Database
   - JWT Authentication
   - Socket.io for real-time messaging

## 📁 Project Structure

```
RShub/
├── flutter_app/                 # Flutter mobile application
│   ├── lib/
│   │   ├── main.dart
│   │   ├── controllers/         # GetX controllers
│   │   ├── models/              # Data models
│   │   ├── screens/             # UI screens
│   │   ├── services/            # API services
│   │   ├── widgets/             # Reusable widgets
│   │   └── utils/               # Utilities
│   └── pubspec.yaml
│
├── backend/                     # Backend API
│   ├── src/
│   │   ├── controllers/         # API controllers
│   │   ├── models/              # Database models
│   │   ├── routes/              # API routes
│   │   ├── middleware/          # Auth & validation
│   │   ├── services/            # Business logic
│   │   └── utils/               # Helper functions
│   └── server.js
│
├── admin_panel/                 # Web admin dashboard
│   ├── src/
│   │   ├── components/          # React components
│   │   ├── pages/               # Admin pages
│   │   ├── services/            # API integration
│   │   └── utils/               # Admin utilities
│   └── package.json
│
└── docs/                        # Documentation
    ├── api.md                   # API documentation
    ├── database.md              # Database schema
    └── deployment.md            # Deployment guide
```

## 🚀 Quick Start

### Prerequisites
- Flutter 3.0+
- Node.js 16+
- MongoDB (for Node.js backend) or Firebase project
- Android Studio / Xcode

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/rshub.git
   cd rshub
   ```

2. **Setup Flutter App**
   ```bash
   cd flutter_app
   flutter pub get
   flutter run
   ```

3. **Setup Backend**
   ```bash
   cd backend
   npm install
   npm run dev
   ```

4. **Setup Admin Panel**
   ```bash
   cd admin_panel
   npm install
   npm start
   ```

## 📱 App Screens

### Authentication
- Phone number login
- OTP verification
- Profile setup

### Main Features
- **Home**: Chats, Groups, Wallet tabs
- **Chat Screen**: Individual and group messaging
- **Wallet**: Earnings dashboard and withdrawal
- **Settings**: App preferences and ad controls

## 💰 Earning Mechanisms

### 1. Group Advertising
- Group owners enable ads
- Revenue split: 70% user, 30% app
- Configurable ad frequency

### 2. File Download Ads
- Media uploads are free
- Downloads require watching 1-3 ads
- Uploader earns from each download

### 3. Chat Advertising
- Users can enable personal chat ads
- Earn from messages in enabled chats
- Anti-fraud protection included

## 🔒 Security Features

- Phone number authentication
- Device limit enforcement
- VPN/proxy detection
- Suspicious activity monitoring
- Block/report system

## 📊 Admin Dashboard

- User management (ban/unban)
- Group monitoring
- Revenue statistics
- Withdrawal approval system
- Ad performance analytics

## 🏗 Database Schema

### Users Collection
```javascript
{
  uid: String,
  phone: String,
  name: String,
  profileImage: String,
  bio: String,
  onlineStatus: Boolean,
  walletBalance: Number,
  totalEarning: Number,
  deviceId: String,
  createdAt: Timestamp
}
```

### Messages Collection
```javascript
{
  messageId: String,
  chatId: String,
  senderId: String,
  content: String,
  type: String, // text, image, video, audio, document
  timestamp: Timestamp,
  isEdited: Boolean,
  isDeleted: Boolean,
  seenBy: Array<String>
}
```

## 🎯 Performance Optimization

- Lazy loading for chat messages
- Image compression and caching
- Efficient real-time connections
- Optimized database queries
- Minimal app size

## 📈 Future Enhancements

- Voice/video calling
- End-to-end encryption
- Multi-language support
- Advanced analytics
- API for third-party integrations

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🔗 Support

For support, email support@rshub.com or join our Discord server.

---

**Built with ❤️ by the RShub Team**