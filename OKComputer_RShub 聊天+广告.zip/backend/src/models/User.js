const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  // Basic Information
  phone: {
    type: String,
    required: true,
    unique: true,
    trim: true,
  },
  email: {
    type: String,
    unique: true,
    sparse: true,
    trim: true,
    lowercase: true,
  },
  name: {
    type: String,
    required: true,
    trim: true,
  },
  profileImage: {
    type: String,
    default: '',
  },
  bio: {
    type: String,
    default: '',
    maxlength: 500,
  },

  // Authentication
  password: {
    type: String,
    required: true,
    minlength: 6,
    select: false,
  },
  otp: {
    type: String,
    select: false,
  },
  otpExpiry: {
    type: Date,
    select: false,
  },
  isVerified: {
    type: Boolean,
    default: false,
  },
  resetPasswordToken: {
    type: String,
    select: false,
  },
  resetPasswordExpiry: {
    type: Date,
    select: false,
  },

  // Status
  onlineStatus: {
    type: Boolean,
    default: false,
  },
  lastSeen: {
    type: Date,
    default: Date.now,
  },
  lastLogin: {
    type: Date,
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  isPremium: {
    type: Boolean,
    default: false,
  },

  // Wallet & Earnings
  walletBalance: {
    type: Number,
    default: 0,
    min: 0,
  },
  totalEarning: {
    type: Number,
    default: 0,
    min: 0,
  },
  todayEarning: {
    type: Number,
    default: 0,
    min: 0,
  },
  pendingBalance: {
    type: Number,
    default: 0,
    min: 0,
  },

  // Ad Settings
  adSettings: {
    groupAdsEnabled: {
      type: Boolean,
      default: false,
    },
    chatAdsEnabled: {
      type: Boolean,
      default: false,
    },
    groupAdFrequency: {
      type: Number,
      default: 10,
      min: 1,
      max: 50,
    },
    chatAdFrequency: {
      type: Number,
      default: 20,
      min: 1,
      max: 50,
    },
    autoPlayAds: {
      type: Boolean,
      default: true,
    },
    adSoundEnabled: {
      type: Boolean,
      default: false,
    },
  },

  // Security
  deviceId: {
    type: String,
    default: '',
  },
  loginAttempts: {
    type: Number,
    default: 0,
  },
  lockUntil: {
    type: Date,
  },

  // Social Features
  blockedUsers: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  }],
  reportedBy: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  }],

  // Referral System
  referralCode: {
    type: String,
    unique: true,
    sparse: true,
  },
  referredBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
  referralCount: {
    type: Number,
    default: 0,
  },
  referralEarnings: {
    type: Number,
    default: 0,
  },

  // Privacy Settings
  privacySettings: {
    showOnlineStatus: {
      type: Boolean,
      default: true,
    },
    showLastSeen: {
      type: Boolean,
      default: true,
    },
    showProfileImage: {
      type: Boolean,
      default: true,
    },
    allowDirectMessages: {
      type: Boolean,
      default: true,
    },
    allowGroupInvites: {
      type: Boolean,
      default: true,
    },
  },

  // Notification Settings
  notificationSettings: {
    pushNotifications: {
      type: Boolean,
      default: true,
    },
    messageNotifications: {
      type: Boolean,
      default: true,
    },
    groupNotifications: {
      type: Boolean,
      default: true,
    },
    earningNotifications: {
      type: Boolean,
      default: true,
    },
    soundEnabled: {
      type: Boolean,
      default: true,
    },
    vibrationEnabled: {
      type: Boolean,
      default: true,
    },
  },

  // Statistics
  stats: {
    messagesSent: {
      type: Number,
      default: 0,
    },
    messagesReceived: {
      type: Number,
      default: 0,
    },
    groupsJoined: {
      type: Number,
      default: 0,
    },
    groupsCreated: {
      type: Number,
      default: 0,
    },
    filesShared: {
      type: Number,
      default: 0,
    },
    adsViewed: {
      type: Number,
      default: 0,
    },
    lastAdView: {
      type: Date,
    },
  },

  // Metadata
  deviceInfo: {
    type: mongoose.Schema.Types.Mixed,
    default: {},
  },
  ipAddress: {
    type: String,
    default: '',
  },
  location: {
    country: String,
    city: String,
    coordinates: [Number], // [longitude, latitude]
  },
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
});

// Indexes
userSchema.index({ phone: 1 });
userSchema.index({ email: 1 });
userSchema.index({ referralCode: 1 });
userSchema.index({ isActive: 1 });
userSchema.index({ onlineStatus: 1 });
userSchema.index({ createdAt: -1 });

// Virtual for account lock status
userSchema.virtual('isLocked').get(function() {
  return !!(this.lockUntil && this.lockUntil > Date.now());
});

// Virtual for initials
userSchema.virtual('initials').get(function() {
  if (!this.name) return this.phone.substring(0, 2).toUpperCase();
  const parts = this.name.split(' ');
  if (parts.length === 1) return parts[0][0].toUpperCase();
  return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
});

// Virtual for display name
userSchema.virtual('displayName').get(function() {
  return this.name || this.phone;
});

// Virtual for can withdraw
userSchema.virtual('canWithdraw').get(function() {
  return this.walletBalance >= 100;
});

// Pre-save middleware
userSchema.pre('save', async function(next) {
  // Generate referral code if not exists
  if (!this.referralCode && this.isVerified) {
    this.referralCode = Math.random().toString(36).substring(2, 8).toUpperCase();
  }
  
  next();
});

// Instance methods
userSchema.methods.incrementLoginAttempts = function() {
  // If we have a previous lock that has expired, restart at 1
  if (this.lockUntil && this.lockUntil < Date.now()) {
    return this.updateOne({
      $set: { loginAttempts: 1 },
      $unset: { lockUntil: 1 },
    });
  }
  
  const updates = { $inc: { loginAttempts: 1 } };
  
  // Lock account after 5 failed attempts for 2 hours
  if (this.loginAttempts + 1 >= 5 && !this.isLocked) {
    updates.$set = {
      lockUntil: Date.now() + 2 * 60 * 60 * 1000, // 2 hours
    };
  }
  
  return this.updateOne(updates);
};

userSchema.methods.resetLoginAttempts = function() {
  return this.updateOne({
    $unset: { loginAttempts: 1, lockUntil: 1 },
  });
};

userSchema.methods.addToWallet = function(amount) {
  this.walletBalance += amount;
  this.totalEarning += amount;
  this.todayEarning += amount;
  return this.save();
};

userSchema.methods.deductFromWallet = function(amount) {
  if (this.walletBalance < amount) {
    throw new Error('Insufficient balance');
  }
  this.walletBalance -= amount;
  return this.save();
};

userSchema.methods.blockUser = function(userId) {
  if (!this.blockedUsers.includes(userId)) {
    this.blockedUsers.push(userId);
  }
  return this.save();
};

userSchema.methods.unblockUser = function(userId) {
  this.blockedUsers = this.blockedUsers.filter(id => id.toString() !== userId.toString());
  return this.save();
};

userSchema.methods.isBlocked = function(userId) {
  return this.blockedUsers.includes(userId);
};

// Static methods
userSchema.statics.findByPhone = function(phone) {
  return this.findOne({ phone });
};

userSchema.statics.findByEmail = function(email) {
  return this.findOne({ email });
};

userSchema.statics.findByReferralCode = function(referralCode) {
  return this.findOne({ referralCode });
};

userSchema.statics.getTopEarners = function(limit = 10) {
  return this.find({ isActive: true })
    .sort({ totalEarning: -1 })
    .limit(limit)
    .select('name profileImage totalEarning referralCount');
};

userSchema.statics.getOnlineUsers = function() {
  return this.find({ onlineStatus: true, isActive: true })
    .select('name profileImage onlineStatus lastSeen');
};

module.exports = mongoose.model('User', userSchema);