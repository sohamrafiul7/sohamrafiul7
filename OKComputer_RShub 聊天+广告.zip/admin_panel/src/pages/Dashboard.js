import React from 'react';
import {
  Box,
  Grid,
  Card,
  CardContent,
  Typography,
  Paper,
  Avatar,
  LinearProgress,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Divider,
  Chip,
  Stack,
} from '@mui/material';
import {
  People as PeopleIcon,
  Group as GroupIcon,
  TrendingUp as TrendingUpIcon,
  AccountBalanceWallet as WalletIcon,
  Warning as WarningIcon,
  CheckCircle as CheckCircleIcon,
  AttachMoney as MoneyIcon,
} from '@mui/icons-material';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { useQuery } from 'react-query';

// Mock data for charts
const earningsData = [
  { name: 'Jan', earnings: 4000, users: 240 },
  { name: 'Feb', earnings: 3000, users: 210 },
  { name: 'Mar', earnings: 5000, users: 290 },
  { name: 'Apr', earnings: 4500, users: 250 },
  { name: 'May', earnings: 6000, users: 320 },
  { name: 'Jun', earnings: 5500, users: 300 },
];

const userActivityData = [
  { name: 'Mon', active: 120, new: 15 },
  { name: 'Tue', active: 132, new: 18 },
  { name: 'Wed', active: 101, new: 12 },
  { name: 'Thu', active: 134, new: 22 },
  { name: 'Fri', active: 90, new: 8 },
  { name: 'Sat', active: 230, new: 35 },
  { name: 'Sun', active: 210, new: 28 },
];

const revenueSourceData = [
  { name: 'Group Ads', value: 45, color: '#0088CC' },
  { name: 'Chat Ads', value: 25, color: '#34B7F1' },
  { name: 'File Downloads', value: 20, color: '#25D366' },
  { name: 'Daily Rewards', value: 10, color: '#F39C12' },
];

const recentActivities = [
  {
    id: 1,
    user: 'John Doe',
    action: 'Completed withdrawal of $50',
    time: '2 minutes ago',
    type: 'withdrawal',
    avatar: '/avatar1.jpg',
  },
  {
    id: 2,
    user: 'Jane Smith',
    action: 'Joined group "Tech Enthusiasts"',
    time: '5 minutes ago',
    type: 'group',
    avatar: '/avatar2.jpg',
  },
  {
    id: 3,
    user: 'Mike Johnson',
    action: 'Earned $0.50 from chat ads',
    time: '10 minutes ago',
    type: 'earning',
    avatar: '/avatar3.jpg',
  },
  {
    id: 4,
    user: 'Sarah Williams',
    action: 'Reported user for spam',
    time: '15 minutes ago',
    type: 'report',
    avatar: '/avatar4.jpg',
  },
];

const topUsers = [
  {
    id: 1,
    name: 'Alice Brown',
    earnings: 1250.50,
    avatar: '/avatar1.jpg',
    status: 'online',
  },
  {
    id: 2,
    name: 'Bob Davis',
    earnings: 980.75,
    avatar: '/avatar2.jpg',
    status: 'offline',
  },
  {
    id: 3,
    name: 'Carol Wilson',
    earnings: 875.20,
    avatar: '/avatar3.jpg',
    status: 'online',
  },
  {
    id: 4,
    name: 'David Miller',
    earnings: 720.40,
    avatar: '/avatar4.jpg',
    status: 'offline',
  },
];

const StatCard = ({ title, value, icon, color, trend, trendValue }) => {
  const getTrendColor = () => {
    if (trend === 'up') return 'success.main';
    if (trend === 'down') return 'error.main';
    return 'text.secondary';
  };

  return (
    <Card sx={{ height: '100%' }}>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box>
            <Typography color="textSecondary" gutterBottom variant="overline">
              {title}
            </Typography>
            <Typography variant="h4" component="div">
              {value}
            </Typography>
            {trend && (
              <Typography variant="caption" color={getTrendColor()} sx={{ mt: 1 }}>
                {trend === 'up' ? '↑' : '↓'} {trendValue}%
              </Typography>
            )}
          </Box>
          <Avatar sx={{ bgcolor: color, width: 56, height: 56 }}>
            {icon}
          </Avatar>
        </Box>
      </CardContent>
    </Card>
  );
};

const Dashboard = () => {
  // In a real application, these would be fetched from the API
  const { data: stats, isLoading } = useQuery('dashboardStats', () => 
    Promise.resolve({
      totalUsers: 12543,
      activeUsers: 8921,
      totalGroups: 345,
      totalEarnings: 45678.90,
      todayEarnings: 2345.67,
      pendingWithdrawals: 156,
      activeReports: 23,
    })
  );

  return (
    <Box sx={{ flexGrow: 1, p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ mb: 3 }}>
        Dashboard Overview
      </Typography>

      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Total Users"
            value={stats?.totalUsers?.toLocaleString() || '0'}
            icon={<PeopleIcon />}
            color="#0088CC"
            trend="up"
            trendValue="12.5"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Active Users"
            value={stats?.activeUsers?.toLocaleString() || '0'}
            icon={<PeopleIcon />}
            color="#25D366"
            trend="up"
            trendValue="8.3"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Total Groups"
            value={stats?.totalGroups?.toLocaleString() || '0'}
            icon={<GroupIcon />}
            color="#F39C12"
            trend="up"
            trendValue="15.2"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Total Earnings"
            value={`$${stats?.totalEarnings?.toLocaleString() || '0'}`}
            icon={<WalletIcon />}
            color="#27AE60"
            trend="up"
            trendValue="22.1"
          />
        </Grid>
      </Grid>

      {/* Charts Section */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        {/* Earnings Chart */}
        <Grid item xs={12} md={8}>
          <Card sx={{ height: 400 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Earnings Overview
              </Typography>
              <ResponsiveContainer width="100%" height={320}>
                <LineChart data={earningsData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value, name) => [
                      name === 'earnings' ? `$${value}` : value,
                      name === 'earnings' ? 'Earnings' : 'Users'
                    ]}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="earnings" 
                    stroke="#0088CC" 
                    strokeWidth={3}
                    dot={{ fill: '#0088CC', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Revenue Sources */}
        <Grid item xs={12} md={4}>
          <Card sx={{ height: 400 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Revenue Sources
              </Typography>
              <ResponsiveContainer width="100%" height={320}>
                <PieChart>
                  <Pie
                    data={revenueSourceData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {revenueSourceData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* User Activity Chart */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12}>
          <Card sx={{ height: 350 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                User Activity (Last 7 Days)
              </Typography>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={userActivityData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="active" fill="#0088CC" name="Active Users" />
                  <Bar dataKey="new" fill="#25D366" name="New Users" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Recent Activities and Top Users */}
      <Grid container spacing={3}>
        {/* Recent Activities */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Recent Activities
              </Typography>
              <List sx={{ maxHeight: 400, overflow: 'auto' }}>
                {recentActivities.map((activity, index) => (
                  <React.Fragment key={activity.id}>
                    <ListItem alignItems="flex-start">
                      <ListItemAvatar>
                        <Avatar src={activity.avatar}>
                          {activity.user.charAt(0)}
                        </Avatar>
                      </ListItemAvatar>
                      <ListItemText
                        primary={
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Typography variant="subtitle2" component="span">
                              {activity.user}
                            </Typography>
                            <Chip
                              size="small"
                              label={activity.type}
                              color={
                                activity.type === 'withdrawal' ? 'warning' :
                                activity.type === 'earning' ? 'success' :
                                activity.type === 'report' ? 'error' : 'default'
                              }
                            />
                          </Box>
                        }
                        secondary={
                          <React.Fragment>
                            <Typography
                              sx={{ display: 'block' }}
                              component="span"
                              variant="body2"
                              color="text.primary"
                            >
                              {activity.action}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {activity.time}
                            </Typography>
                          </React.Fragment>
                        }
                      />
                    </ListItem>
                    {index < recentActivities.length - 1 && <Divider variant="inset" component="li" />}
                  </React.Fragment>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>

        {/* Top Users */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Top Earners
              </Typography>
              <List sx={{ maxHeight: 400, overflow: 'auto' }}>
                {topUsers.map((user, index) => (
                  <React.Fragment key={user.id}>
                    <ListItem alignItems="center">
                      <ListItemAvatar>
                        <Avatar src={user.avatar}>
                          {user.name.charAt(0)}
                        </Avatar>
                      </ListItemAvatar>
                      <ListItemText
                        primary={
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Typography variant="subtitle2">
                              {user.name}
                            </Typography>
                            <Chip
                              size="small"
                              label={user.status}
                              color={user.status === 'online' ? 'success' : 'default'}
                              variant="outlined"
                            />
                          </Box>
                        }
                        secondary={`$${user.earnings.toFixed(2)} earned`}
                      />
                      <Typography variant="h6" color="primary">
                        #{index + 1}
                      </Typography>
                    </ListItem>
                    {index < topUsers.length - 1 && <Divider variant="inset" component="li" />}
                  </React.Fragment>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Quick Stats Bar */}
      <Box sx={{ mt: 3, display: 'flex', gap: 2, flexWrap: 'wrap' }}>
        <Chip
          icon={<MoneyIcon />}
          label={`Today's Earnings: $${stats?.todayEarnings?.toFixed(2) || '0'}`}
          color="success"
          variant="outlined"
        />
        <Chip
          icon={<WarningIcon />}
          label={`Pending Withdrawals: ${stats?.pendingWithdrawals || 0}`}
          color="warning"
          variant="outlined"
        />
        <Chip
          icon={<CheckCircleIcon />}
          label={`Active Reports: ${stats?.activeReports || 0}`}
          color="error"
          variant="outlined"
        />
      </Box>
    </Box>
  );
};

export default Dashboard;