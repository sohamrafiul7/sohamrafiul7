# RShub API Documentation

This document provides comprehensive documentation for the RShub REST API endpoints.

## Base URL

- **Development**: `http://localhost:3000/api`
- **Production**: `https://api.rshub.com/api`

## Authentication

Most endpoints require authentication using JWT tokens. Include the token in the Authorization header:

```
Authorization: Bearer <your_jwt_token>
```

## Response Format

All responses follow a consistent format:

```json
{
  "success": true,
  "message": "Operation completed successfully",
  "data": { ... },
  "errors": []
}
```

## Error Handling

Error responses include appropriate HTTP status codes and error details:

```json
{
  "success": false,
  "message": "Validation error",
  "errors": [
    {
      "field": "email",
      "message": "Email is required"
    }
  ]
}
```

## API Endpoints

### Authentication Endpoints

#### Register User
```http
POST /auth/register
Content-Type: application/json

{
  "phone": "+8801234567890",
  "name": "John Doe",
  "email": "john@example.com",
  "password": "securepassword123"
}

Response: 201 Created
{
  "success": true,
  "message": "User registered successfully. Please verify your phone number.",
  "data": {
    "userId": "user_id",
    "phone": "+8801234567890"
  }
}
```

#### Login
```http
POST /auth/login
Content-Type: application/json

{
  "phone": "+8801234567890",
  "password": "securepassword123"
}

Response: 200 OK
{
  "success": true,
  "message": "Login successful",
  "data": {
    "token": "jwt_token",
    "refreshToken": "refresh_token",
    "user": {
      "id": "user_id",
      "phone": "+8801234567890",
      "name": "John Doe",
      "email": "john@example.com",
      "profileImage": "https://...",
      "walletBalance": 125.50,
      "totalEarning": 345.75
    }
  }
}
```

#### Verify OTP
```http
POST /auth/verify-otp
Content-Type: application/json

{
  "phone": "+8801234567890",
  "otp": "123456"
}

Response: 200 OK
{
  "success": true,
  "message": "Phone number verified successfully"
}
```

#### Resend OTP
```http
POST /auth/resend-otp
Content-Type: application/json

{
  "phone": "+8801234567890"
}

Response: 200 OK
{
  "success": true,
  "message": "OTP sent successfully"
}
```

#### Refresh Token
```http
POST /auth/refresh-token
Content-Type: application/json

{
  "refreshToken": "refresh_token"
}

Response: 200 OK
{
  "success": true,
  "data": {
    "token": "new_jwt_token"
  }
}
```

#### Logout
```http
POST /auth/logout
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "refreshToken": "refresh_token"
}

Response: 200 OK
{
  "success": true,
  "message": "Logged out successfully"
}
```

#### Get Current User
```http
GET /auth/me
Authorization: Bearer <jwt_token>

Response: 200 OK
{
  "success": true,
  "data": {
    "user": {
      "id": "user_id",
      "phone": "+8801234567890",
      "name": "John Doe",
      "email": "john@example.com",
      "profileImage": "https://...",
      "bio": "Software developer",
      "onlineStatus": true,
      "walletBalance": 125.50,
      "totalEarning": 345.75,
      "todayEarning": 15.25,
      "isActive": true,
      "isPremium": false,
      "createdAt": "2024-01-15T10:30:00.000Z"
    }
  }
}
```

### Chat Endpoints

#### Get User Chats
```http
GET /chat/chats
Authorization: Bearer <jwt_token>

Response: 200 OK
{
  "success": true,
  "data": {
    "chats": [
      {
        "chatId": "chat_id",
        "type": "individual",
        "participants": ["user_id_1", "user_id_2"],
        "lastMessage": {
          "messageId": "message_id",
          "senderId": "user_id",
          "content": "Hello",
          "type": "text",
          "timestamp": "2024-01-15T10:30:00.000Z"
        },
        "unreadCount": 3,
        "lastMessageTime": "2024-01-15T10:30:00.000Z"
      }
    ]
  }
}
```

#### Get Chat Messages
```http
GET /chat/messages?chatId=chat_id&limit=50&offset=0
Authorization: Bearer <jwt_token>

Response: 200 OK
{
  "success": true,
  "data": {
    "messages": [
      {
        "messageId": "message_id",
        "chatId": "chat_id",
        "senderId": "user_id",
        "content": "Hello, how are you?",
        "type": "text",
        "timestamp": "2024-01-15T10:30:00.000Z",
        "isEdited": false,
        "isDeleted": false,
        "seenBy": ["user_id_1", "user_id_2"],
        "deliveredTo": ["user_id_1", "user_id_2"]
      }
    ],
    "hasMore": true,
    "total": 150
  }
}
```

#### Send Message
```http
POST /chat/send-message
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "chatId": "chat_id",
  "content": "Hello, how are you?",
  "type": "text",
  "replyTo": "message_id" // optional
}

Response: 200 OK
{
  "success": true,
  "message": "Message sent successfully",
  "data": {
    "messageId": "message_id",
    "chatId": "chat_id",
    "senderId": "user_id",
    "content": "Hello, how are you?",
    "type": "text",
    "timestamp": "2024-01-15T10:30:00.000Z"
  }
}
```

#### Send Media Message
```http
POST /chat/send-media
Authorization: Bearer <jwt_token>
Content-Type: multipart/form-data

Form Data:
- chatId: chat_id
- type: image
- file: <binary_file_data>
- caption: "Check this out" (optional)

Response: 200 OK
{
  "success": true,
  "message": "Media sent successfully",
  "data": {
    "messageId": "message_id",
    "fileUrl": "https://storage.googleapis.com/...",
    "thumbnailUrl": "https://storage.googleapis.com/..."
  }
}
```

#### Edit Message
```http
PUT /chat/edit-message
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "chatId": "chat_id",
  "messageId": "message_id",
  "newContent": "Updated message content"
}

Response: 200 OK
{
  "success": true,
  "message": "Message edited successfully"
}
```

#### Delete Message
```http
DELETE /chat/delete-message
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "chatId": "chat_id",
  "messageId": "message_id",
  "deleteForEveryone": true // optional, default: false
}

Response: 200 OK
{
  "success": true,
  "message": "Message deleted successfully"
}
```

#### Create Individual Chat
```http
POST /chat/create-individual-chat
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "userId": "other_user_id"
}

Response: 200 OK
{
  "success": true,
  "data": {
    "chatId": "chat_id",
    "type": "individual",
    "participants": ["user_id_1", "user_id_2"]
  }
}
```

### Group Endpoints

#### Create Group
```http
POST /groups/create
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "name": "Tech Enthusiasts",
  "description": "A community for tech discussions",
  "isPublic": false,
  "initialMembers": ["user_id_1", "user_id_2"]
}

Response: 201 Created
{
  "success": true,
  "message": "Group created successfully",
  "data": {
    "groupId": "group_id",
    "name": "Tech Enthusiasts",
    "inviteLink": "https://rshub.com/invite/abc123"
  }
}
```

#### Get Group Details
```http
GET /groups/details?groupId=group_id
Authorization: Bearer <jwt_token>

Response: 200 OK
{
  "success": true,
  "data": {
    "groupId": "group_id",
    "name": "Tech Enthusiasts",
    "description": "A community for tech discussions",
    "groupImage": "https://...",
    "memberCount": 156,
    "members": [
      {
        "userId": "user_id",
        "name": "John Doe",
        "profileImage": "https://...",
        "role": "admin" // "admin", "moderator", "member"
      }
    ],
    "createdBy": "user_id",
    "admins": ["user_id_1", "user_id_2"],
    "isPublic": false,
    "adRevenueEnabled": true
  }
}
```

#### Join Group
```http
POST /groups/join
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "groupId": "group_id",
  "inviteLink": "https://rshub.com/invite/abc123" // optional
}

Response: 200 OK
{
  "success": true,
  "message": "Joined group successfully"
}
```

#### Leave Group
```http
POST /groups/leave
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "groupId": "group_id"
}

Response: 200 OK
{
  "success": true,
  "message": "Left group successfully"
}
```

#### Add Group Members
```http
POST /groups/add-members
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "groupId": "group_id",
  "userIds": ["user_id_1", "user_id_2"]
}

Response: 200 OK
{
  "success": true,
  "message": "Members added successfully"
}
```

#### Remove Group Members
```http
POST /groups/remove-members
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "groupId": "group_id",
  "userIds": ["user_id_1", "user_id_2"]
}

Response: 200 OK
{
  "success": true,
  "message": "Members removed successfully"
}
```

#### Update Group Settings
```http
PUT /groups/settings
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "groupId": "group_id",
  "adRevenueEnabled": true,
  "adFrequency": 15
}

Response: 200 OK
{
  "success": true,
  "message": "Group settings updated successfully"
}
```

### Wallet Endpoints

#### Get Wallet Info
```http
GET /wallet/info
Authorization: Bearer <jwt_token>

Response: 200 OK
{
  "success": true,
  "data": {
    "totalEarning": 345.75,
    "todayEarning": 15.25,
    "walletBalance": 125.50,
    "pendingBalance": 0.0,
    "canWithdraw": true,
    "minimumWithdrawal": 100.0
  }
}
```

#### Get Transaction History
```http
GET /wallet/transactions?limit=50&offset=0&type=earning
Authorization: Bearer <jwt_token>

Response: 200 OK
{
  "success": true,
  "data": {
    "transactions": [
      {
        "transactionId": "transaction_id",
        "type": "earning",
        "amount": 0.50,
        "source": "group_ad",
        "description": "Earning from group ad view",
        "status": "completed",
        "timestamp": "2024-01-15T10:30:00.000Z",
        "formattedAmount": "+$0.50",
        "amountColor": "success"
      }
    ],
    "hasMore": true,
    "total": 150
  }
}
```

#### Get Earnings Breakdown
```http
GET /wallet/earnings-breakdown
Authorization: Bearer <jwt_token>

Response: 200 OK
{
  "success": true,
  "data": {
    "breakdown": {
      "group_ads": 125.50,
      "chat_ads": 75.25,
      "file_download_ads": 95.00,
      "daily_rewards": 50.00
    },
    "total": 345.75
  }
}
```

#### Get Monthly Earnings
```http
GET /wallet/monthly-earnings
Authorization: Bearer <jwt_token>

Response: 200 OK
{
  "success": true,
  "data": {
    "monthlyData": {
      "2024-01": 125.50,
      "2024-02": 98.75,
      "2024-03": 156.20,
      "2024-04": 134.30,
      "2024-05": 178.45,
      "2024-06": 142.55
    }
  }
}
```

#### Request Withdrawal
```http
POST /wallet/withdraw
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "amount": 100.00,
  "paymentMethod": "bKash",
  "accountNumber": "+8801234567890",
  "accountName": "John Doe"
}

Response: 200 OK
{
  "success": true,
  "message": "Withdrawal request submitted successfully",
  "data": {
    "withdrawalId": "withdrawal_id",
    "amount": 100.00,
    "paymentMethod": "bKash",
    "status": "pending"
  }
}
```

#### Get Withdrawal History
```http
GET /wallet/withdrawals
Authorization: Bearer <jwt_token>

Response: 200 OK
{
  "success": true,
  "data": {
    "withdrawals": [
      {
        "withdrawalId": "withdrawal_id",
        "amount": 100.00,
        "paymentMethod": "bKash",
        "accountNumber": "+8801234567890",
        "status": "completed",
        "requestedAt": "2024-01-15T10:30:00.000Z",
        "processedAt": "2024-01-15T14:30:00.000Z"
      }
    ]
  }
}
```

### User Endpoints

#### Update Profile
```http
PUT /users/profile
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "name": "John Doe",
  "bio": "Software developer and tech enthusiast",
  "profileImage": "https://..."
}

Response: 200 OK
{
  "success": true,
  "message": "Profile updated successfully"
}
```

#### Update Online Status
```http
PUT /users/online-status
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "onlineStatus": true
}

Response: 200 OK
{
  "success": true,
  "message": "Online status updated successfully"
}
```

#### Update Ad Settings
```http
PUT /users/ad-settings
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "groupAdsEnabled": true,
  "chatAdsEnabled": false,
  "groupAdFrequency": 15,
  "chatAdFrequency": 25
}

Response: 200 OK
{
  "success": true,
  "message": "Ad settings updated successfully"
}
```

#### Block User
```http
POST /users/block
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "userId": "user_to_block_id"
}

Response: 200 OK
{
  "success": true,
  "message": "User blocked successfully"
}
```

#### Unblock User
```http
POST /users/unblock
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "userId": "user_to_unblock_id"
}

Response: 200 OK
{
  "success": true,
  "message": "User unblocked successfully"
}
```

#### Report User
```http
POST /users/report
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "userId": "reported_user_id",
  "category": "spam",
  "description": "This user is sending spam messages",
  "evidence": ["message_id_1", "message_id_2"]
}

Response: 200 OK
{
  "success": true,
  "message": "User reported successfully"
}
```

### Admin Endpoints

#### Get Dashboard Stats
```http
GET /admin/dashboard-stats
Authorization: Bearer <admin_jwt_token>

Response: 200 OK
{
  "success": true,
  "data": {
    "totalUsers": 12543,
    "activeUsers": 8921,
    "totalGroups": 345,
    "totalEarnings": 45678.90,
    "todayEarnings": 2345.67,
    "pendingWithdrawals": 156,
    "activeReports": 23,
    "blockedUsers": 45
  }
}
```

#### Get All Users
```http
GET /admin/users?limit=50&offset=0&search=john&status=active
Authorization: Bearer <admin_jwt_token>

Response: 200 OK
{
  "success": true,
  "data": {
    "users": [
      {
        "id": "user_id",
        "phone": "+8801234567890",
        "name": "John Doe",
        "email": "john@example.com",
        "onlineStatus": true,
        "walletBalance": 125.50,
        "totalEarning": 345.75,
        "isActive": true,
        "isVerified": true,
        "createdAt": "2024-01-15T10:30:00.000Z",
        "lastLogin": "2024-01-15T10:30:00.000Z"
      }
    ],
    "total": 12543,
    "hasMore": true
  }
}
```

#### Ban User
```http
POST /admin/users/ban
Authorization: Bearer <admin_jwt_token>
Content-Type: application/json

{
  "userId": "user_id",
  "reason": "Violation of community guidelines",
  "duration": 30 // days, 0 for permanent
}

Response: 200 OK
{
  "success": true,
  "message": "User banned successfully"
}
```

#### Unban User
```http
POST /admin/users/unban
Authorization: Bearer <admin_jwt_token>
Content-Type: application/json

{
  "userId": "user_id"
}

Response: 200 OK
{
  "success": true,
  "message": "User unbanned successfully"
}
```

#### Get Withdrawal Requests
```http
GET /admin/withdrawals?status=pending&limit=50&offset=0
Authorization: Bearer <admin_jwt_token>

Response: 200 OK
{
  "success": true,
  "data": {
    "withdrawals": [
      {
        "withdrawalId": "withdrawal_id",
        "userId": "user_id",
        "userName": "John Doe",
        "amount": 100.00,
        "paymentMethod": "bKash",
        "accountNumber": "+8801234567890",
        "status": "pending",
        "requestedAt": "2024-01-15T10:30:00.000Z"
      }
    ],
    "total": 156,
    "hasMore": true
  }
}
```

#### Approve Withdrawal
```http
POST /admin/withdrawals/approve
Authorization: Bearer <admin_jwt_token>
Content-Type: application/json

{
  "withdrawalId": "withdrawal_id",
  "transactionReference": "TXN123456"
}

Response: 200 OK
{
  "success": true,
  "message": "Withdrawal approved successfully"
}
```

#### Reject Withdrawal
```http
POST /admin/withdrawals/reject
Authorization: Bearer <admin_jwt_token>
Content-Type: application/json

{
  "withdrawalId": "withdrawal_id",
  "reason": "Invalid account number"
}

Response: 200 OK
{
  "success": true,
  "message": "Withdrawal rejected successfully"
}
```

#### Get Reports
```http
GET /admin/reports?status=pending&limit=50&offset=0
Authorization: Bearer <admin_jwt_token>

Response: 200 OK
{
  "success": true,
  "data": {
    "reports": [
      {
        "reportId": "report_id",
        "reporterId": "reporter_user_id",
        "reporterName": "Jane Doe",
        "reportedUserId": "reported_user_id",
        "reportedUserName": "John Doe",
        "category": "spam",
        "description": "Sending spam messages",
        "status": "pending",
        "priority": "medium",
        "createdAt": "2024-01-15T10:30:00.000Z"
      }
    ],
    "total": 23,
    "hasMore": true
  }
}
```

#### Resolve Report
```http
POST /admin/reports/resolve
Authorization: Bearer <admin_jwt_token>
Content-Type: application/json

{
  "reportId": "report_id",
  "resolution": "User warned and inappropriate content removed",
  "actionTaken": "warning"
}

Response: 200 OK
{
  "success": true,
  "message": "Report resolved successfully"
}
```

#### Send Global Notification
```http
POST /admin/notifications/send
Authorization: Bearer <admin_jwt_token>
Content-Type: application/json

{
  "title": "New Feature Available",
  "message": "Check out our new video calling feature!",
  "targetUsers": ["user_id_1", "user_id_2"], // optional, send to all if not specified
  "scheduledFor": "2024-01-16T10:00:00.000Z" // optional
}

Response: 200 OK
{
  "success": true,
  "message": "Notification sent successfully"
}
```

## WebSocket Events

The application uses Socket.IO for real-time features. Here are the main events:

### Client to Server Events

#### Join Chat
```javascript
socket.emit('join-chat', {
  chatId: 'chat_id',
  userId: 'user_id'
});
```

#### Send Typing Indicator
```javascript
socket.emit('typing', {
  chatId: 'chat_id',
  userId: 'user_id',
  isTyping: true
});
```

#### Send Message
```javascript
socket.emit('send-message', {
  chatId: 'chat_id',
  message: {
    content: 'Hello',
    type: 'text'
  }
});
```

### Server to Client Events

#### New Message
```javascript
socket.on('new-message', (data) => {
  console.log('New message:', data.message);
});
```

#### User Typing
```javascript
socket.on('user-typing', (data) => {
  console.log('User typing:', data.userId, data.isTyping);
});
```

#### Message Delivered
```javascript
socket.on('message-delivered', (data) => {
  console.log('Message delivered:', data.messageId);
});
```

#### Message Seen
```javascript
socket.on('message-seen', (data) => {
  console.log('Message seen:', data.messageId);
});
```

## Rate Limiting

API endpoints are rate-limited to prevent abuse:

- **General endpoints**: 100 requests per 15 minutes per IP
- **Auth endpoints**: 5 requests per 15 minutes per IP
- **Message sending**: 10 messages per minute per user
- **File uploads**: 5 uploads per minute per user

## Error Codes

| Code | Description |
|------|-------------|
| 400 | Bad Request - Invalid input data |
| 401 | Unauthorized - Invalid or missing token |
| 403 | Forbidden - Insufficient permissions |
| 404 | Not Found - Resource not found |
| 429 | Too Many Requests - Rate limit exceeded |
| 500 | Internal Server Error - Server error |

## Support

For API support or questions, please contact:
- Email: support@rshub.com
- Documentation: https://docs.rshub.com
- Status Page: https://status.rshub.com