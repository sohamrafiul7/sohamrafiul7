# RShub Deployment Guide

This guide provides comprehensive instructions for deploying the RShub application across all components.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Environment Setup](#environment-setup)
3. [Flutter App Deployment](#flutter-app-deployment)
4. [Backend API Deployment](#backend-api-deployment)
5. [Admin Panel Deployment](#admin-panel-deployment)
6. [Database Setup](#database-setup)
7. [Firebase Configuration](#firebase-configuration)
8. [Production Deployment](#production-deployment)
9. [Monitoring and Maintenance](#monitoring-and-maintenance)
10. [Troubleshooting](#troubleshooting)

## Prerequisites

### System Requirements

- **Node.js**: 16.0.0 or higher
- **Flutter**: 3.0.0 or higher
- **MongoDB**: 5.0 or higher
- **Redis**: 6.0 or higher
- **Git**: Latest version
- **Docker**: Latest version (optional)

### Development Tools

- **VS Code** or **Android Studio**
- **Postman** or **Insomnia** (API testing)
- **MongoDB Compass** (database management)
- **Firebase CLI**

## Environment Setup

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/rshub.git
cd rshub
```

### 2. Install Dependencies

#### Flutter App
```bash
cd flutter_app
flutter pub get
```

#### Backend API
```bash
cd backend
npm install
```

#### Admin Panel
```bash
cd admin_panel
npm install
```

### 3. Environment Variables

Create environment files for each component:

#### Backend (.env)
```bash
# Copy example file
cp .env.example .env

# Edit with your values
nano .env
```

#### Flutter App
Create `flutter_app/lib/config/app_config.dart` with your configuration.

#### Admin Panel (.env)
```bash
# Create .env file in admin_panel directory
REACT_APP_API_URL=http://localhost:3000/api
REACT_APP_SOCKET_URL=http://localhost:3000
```

## Flutter App Deployment

### Development Setup

1. **Configure Firebase**
   ```bash
   cd flutter_app
   flutterfire configure
   ```

2. **Add Platform Configurations**
   ```bash
   # For Android
   flutter build apk --debug
   
   # For iOS (macOS only)
   flutter build ios --debug
   ```

3. **Run Development Server**
   ```bash
   flutter run
   ```

### Production Build

#### Android
```bash
# Build APK
flutter build apk --release

# Build App Bundle for Google Play
flutter build appbundle --release
```

#### iOS
```bash
# Build for release
flutter build ios --release

# Create archive for App Store
flutter build ipa --release
```

### App Store Deployment

#### Google Play Store

1. **Create Google Play Developer Account**
   - Visit [Google Play Console](https://play.google.com/console)
   - Pay $25 registration fee

2. **Prepare App Listing**
   - App name: RShub
   - Short description: Chat, Connect & Earn
   - Full description: [Use app description from README]
   - Screenshots: Take screenshots of key features
   - Icon: Use app icon from assets

3. **Upload APK/App Bundle**
   ```bash
   flutter build appbundle --release
   ```

4. **Configure Store Listing**
   - Category: Communication
   - Content rating: Complete questionnaire
   - Pricing: Free with ads
   - Distribution countries: Select target markets

5. **Release App**
   - Create release in Google Play Console
   - Upload signed app bundle
   - Submit for review

#### Apple App Store

1. **Create Apple Developer Account**
   - Visit [Apple Developer](https://developer.apple.com)
   - Pay $99 annual fee

2. **Create App ID and Certificates**
   ```bash
   # Create provisioning profiles
   open ios/Runner.xcworkspace
   ```

3. **Prepare App Store Listing**
   - App name: RShub
   - Subtitle: Chat & Earn Money
   - Description: [Use app description]
   - Keywords: chat, messaging, earn money, social
   - Screenshots: Use App Store Connect templates

4. **Build and Upload**
   ```bash
   flutter build ipa --release
   ```

5. **Submit for Review**
   - Use App Store Connect
   - Complete app information
   - Submit for review

## Backend API Deployment

### Development Setup

1. **Configure Environment**
   ```bash
   cd backend
   cp .env.example .env
   # Edit .env with your configuration
   ```

2. **Start Development Server**
   ```bash
   npm run dev
   ```

### Production Deployment

#### Using PM2 (Recommended)

1. **Install PM2 Globally**
   ```bash
   npm install -g pm2
   ```

2. **Create PM2 Configuration**
   ```javascript
   // ecosystem.config.js
   module.exports = {
     apps: [{
       name: 'rshub-backend',
       script: 'server.js',
       instances: 'max',
       exec_mode: 'cluster',
       env: {
         NODE_ENV: 'production',
         PORT: 3000
       },
       error_file: './logs/err.log',
       out_file: './logs/out.log',
       log_file: './logs/combined.log',
       time: true
     }]
   };
   ```

3. **Start Application**
   ```bash
   pm2 start ecosystem.config.js
   pm2 save
   pm2 startup
   ```

#### Using Docker

1. **Create Dockerfile**
   ```dockerfile
   FROM node:16-alpine
   
   WORKDIR /app
   
   COPY package*.json ./
   RUN npm ci --only=production
   
   COPY . .
   
   EXPOSE 3000
   
   CMD ["node", "server.js"]
   ```

2. **Build and Run**
   ```bash
   docker build -t rshub-backend .
   docker run -p 3000:3000 --env-file .env rshub-backend
   ```

#### Using Docker Compose

```yaml
# docker-compose.yml
version: '3.8'

services:
  backend:
    build: ./backend
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
    env_file:
      - ./backend/.env
    depends_on:
      - mongodb
      - redis
    volumes:
      - ./backend/logs:/app/logs

  mongodb:
    image: mongo:5.0
    ports:
      - "27017:27017"
    environment:
      - MONGO_INITDB_ROOT_USERNAME=admin
      - MONGO_INITDB_ROOT_PASSWORD=password
    volumes:
      - mongodb_data:/data/db

  redis:
    image: redis:6-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data

volumes:
  mongodb_data:
  redis_data:
```

### Cloud Deployment Options

#### AWS EC2

1. **Launch EC2 Instance**
   - Choose Ubuntu 20.04 LTS
   - Select appropriate instance type (t3.medium recommended)
   - Configure security groups (ports 22, 80, 443, 3000)

2. **Setup Server**
   ```bash
   # Update system
   sudo apt update && sudo apt upgrade -y
   
   # Install Node.js
   curl -fsSL https://deb.nodesource.com/setup_16.x | sudo -E bash -
   sudo apt-get install -y nodejs
   
   # Install PM2
   sudo npm install -g pm2
   
   # Install MongoDB
   wget -qO - https://www.mongodb.org/static/pgp/server-5.0.asc | sudo apt-key add -
   echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/5.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-5.0.list
   sudo apt-get update
   sudo apt-get install -y mongodb-org
   
   # Install Redis
   sudo apt install redis-server
   ```

3. **Deploy Application**
   ```bash
   # Clone repository
   git clone https://github.com/yourusername/rshub.git
   cd rshub/backend
   
   # Install dependencies
   npm install
   
   # Configure environment
   cp .env.example .env
   # Edit .env file
   
   # Start with PM2
   pm2 start ecosystem.config.js
   pm2 startup
   pm2 save
   ```

4. **Setup Reverse Proxy (Nginx)**
   ```nginx
   server {
       listen 80;
       server_name api.rshub.com;
   
       location / {
           proxy_pass http://localhost:3000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

#### Google Cloud Platform

1. **Create Compute Engine Instance**
   - Choose e2-medium instance
   - Allow HTTP/HTTPS traffic
   - Add firewall rules for port 3000

2. **Deploy Using Cloud Shell**
   ```bash
   # Clone repository
   git clone https://github.com/yourusername/rshub.git
   
   # Deploy to App Engine
   cd rshub/backend
   gcloud app deploy
   ```

#### Heroku

1. **Create Heroku App**
   ```bash
   heroku create rshub-backend
   ```

2. **Configure Environment Variables**
   ```bash
   heroku config:set NODE_ENV=production
   heroku config:set MONGODB_URI=mongodb://...
   # Add other environment variables
   ```

3. **Deploy**
   ```bash
   git add .
   git commit -m "Deploy to Heroku"
   git push heroku main
   ```

## Admin Panel Deployment

### Development Setup

1. **Configure Environment**
   ```bash
   cd admin_panel
   cp .env.example .env
   # Edit .env file
   ```

2. **Start Development Server**
   ```bash
   npm start
   ```

### Production Build

1. **Build Application**
   ```bash
   npm run build
   ```

2. **Deploy to Static Hosting**

#### Netlify
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Deploy
netlify deploy --prod --dir=build
```

#### Vercel
```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel --prod
```

#### AWS S3 + CloudFront
```bash
# Build application
npm run build

# Upload to S3
aws s3 sync build/ s3://your-admin-panel-bucket

# Invalidate CloudFront cache
aws cloudfront create-invalidation --distribution-id YOUR_DISTRIBUTION_ID --paths "/*"
```

## Database Setup

### MongoDB Setup

#### Local Development
```bash
# Install MongoDB
sudo apt install mongodb

# Start MongoDB
sudo systemctl start mongodb

# Create database
mongo
use rshub

# Create user
db.createUser({
  user: 'rshub_user',
  pwd: 'secure_password',
  roles: [{ role: 'readWrite', db: 'rshub' }]
})
```

#### MongoDB Atlas (Recommended)

1. **Create Cluster**
   - Visit [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
   - Create free tier cluster
   - Configure network access (allow all IPs for development)

2. **Create Database User**
   - Add database user with read/write permissions
   - Note connection string

3. **Configure Connection**
   ```bash
   # Add to .env file
   MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/rshub?retryWrites=true&w=majority
   ```

### Redis Setup

#### Local Development
```bash
# Install Redis
sudo apt install redis-server

# Configure Redis
sudo nano /etc/redis/redis.conf
# Set supervised systemd
# Set bind 127.0.0.1

# Start Redis
sudo systemctl start redis-server
```

#### Redis Cloud (Production)

1. **Create Redis Instance**
   - Visit [Redis Cloud](https://redis.com/redis-cloud/)
   - Create free tier instance
   - Note connection details

2. **Configure Connection**
   ```bash
   # Add to .env file
   REDIS_URL=redis://default:password@redis-12345.c15.us-east-1-2.ec2.cloud.redislabs.com:12345
   ```

## Firebase Configuration

### Setup Firebase Project

1. **Create Firebase Project**
   - Visit [Firebase Console](https://console.firebase.google.com)
   - Create new project
   - Enable required services

2. **Configure Services**
   ```bash
   # Install Firebase CLI
   npm install -g firebase-tools
   
   # Login to Firebase
   firebase login
   
   # Initialize Firebase in Flutter app
   cd flutter_app
   flutterfire configure
   ```

3. **Enable Firebase Services**
   - Authentication (Phone)
   - Firestore Database
   - Cloud Storage
   - Cloud Messaging
   - Firebase Functions (optional)

### Configure Firebase Rules

#### Firestore Rules
```javascript
// firestore.rules
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Add your security rules here
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

#### Storage Rules
```javascript
// storage.rules
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /users/{userId}/{allPaths=**} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

## Production Deployment

### SSL Certificate Setup

#### Using Let's Encrypt
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d api.rshub.com

# Auto-renewal
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

### Domain Configuration

#### DNS Records
```
A     api.rshub.com     -> YOUR_SERVER_IP
A     admin.rshub.com   -> YOUR_SERVER_IP
A     rshub.com         -> YOUR_SERVER_IP
CNAME www.rshub.com     -> rshub.com
```

### Load Balancing (Optional)

#### Using Nginx Load Balancer
```nginx
upstream backend {
    server 127.0.0.1:3000;
    server 127.0.0.1:3001;
    server 127.0.0.1:3002;
}

server {
    listen 80;
    server_name api.rshub.com;
    
    location / {
        proxy_pass http://backend;
        # ... other proxy settings
    }
}
```

### CDN Setup

#### Cloudflare Configuration
1. **Add Site to Cloudflare**
   - Update nameservers
   - Configure DNS records

2. **Enable Features**
   - SSL/TLS (Full)
   - Caching
   - DDoS protection
   - Rate limiting

## Monitoring and Maintenance

### Application Monitoring

#### PM2 Monitoring
```bash
# Monitor application
pm2 monit

# View logs
pm2 logs

# Application status
pm2 status

# Restart application
pm2 restart rshub-backend
```

#### Health Checks
```bash
# Create health check endpoint
curl https://api.rshub.com/health
```

### Database Monitoring

#### MongoDB Monitoring
```bash
# Check MongoDB status
sudo systemctl status mongod

# View MongoDB logs
sudo tail -f /var/log/mongodb/mongod.log

# MongoDB statistics
mongo --eval "db.stats()"
```

#### Redis Monitoring
```bash
# Check Redis status
sudo systemctl status redis

# Redis CLI
redis-cli
127.0.0.1:6379> ping
127.0.0.1:6379> info
```

### Log Management

#### Log Rotation
```bash
# Configure logrotate
sudo nano /etc/logrotate.d/rshub

# Add configuration
/path/to/rshub/logs/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 appuser appuser
    sharedscripts
    postrotate
        pm2 reload rshub-backend
    endscript
}
```

#### Centralized Logging
```bash
# Install ELK Stack (optional)
# Configure Filebeat to send logs to Elasticsearch
```

### Backup Strategy

#### Database Backup
```bash
# MongoDB backup script
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups/mongodb"

mongodump --host localhost:27017 --db rshub --out $BACKUP_DIR/$DATE
tar -czf $BACKUP_DIR/mongodb_backup_$DATE.tar.gz $BACKUP_DIR/$DATE
rm -rf $BACKUP_DIR/$DATE

# Keep only last 7 days
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete
```

#### Application Backup
```bash
# Backup application files
tar -czf /backups/rshub_app_$(date +%Y%m%d).tar.gz /path/to/rshub
```

## Troubleshooting

### Common Issues

#### Port Already in Use
```bash
# Find process using port
sudo lsof -i :3000

# Kill process
sudo kill -9 PID
```

#### Database Connection Issues
```bash
# Check MongoDB status
sudo systemctl status mongod

# Restart MongoDB
sudo systemctl restart mongod

# Check connection
mongo --eval "db.runCommand({ping: 1})"
```

#### Memory Issues
```bash
# Check memory usage
free -h

# Check process memory usage
ps aux --sort=-%mem | head -10

# Restart application if needed
pm2 restart rshub-backend
```

### Performance Optimization

#### Node.js Optimization
```javascript
// server.js optimizations
const cluster = require('cluster');
const numCPUs = require('os').cpus().length;

if (cluster.isMaster) {
  for (let i = 0; i < numCPUs; i++) {
    cluster.fork();
  }
} else {
  // Start server
}
```

#### Database Optimization
```javascript
// Add database indexes
userSchema.index({ phone: 1 });
userSchema.index({ onlineStatus: 1, lastSeen: -1 });
```

### Security Checklist

- [ ] Use HTTPS with valid SSL certificate
- [ ] Configure firewall rules
- [ ] Set up rate limiting
- [ ] Use strong passwords and API keys
- [ ] Enable CORS with specific origins
- [ ] Validate and sanitize all inputs
- [ ] Keep dependencies updated
- [ ] Use environment variables for secrets
- [ ] Implement proper error handling
- [ ] Set up monitoring and alerts

### Support and Maintenance

#### Regular Tasks
- [ ] Update dependencies weekly
- [ ] Monitor application logs daily
- [ ] Check database performance weekly
- [ ] Review security alerts daily
- [ ] Backup databases daily
- [ ] Update SSL certificates before expiry

#### Emergency Procedures
1. **Application Down**
   - Check PM2 status
   - Review error logs
   - Restart if necessary
   - Contact team if issues persist

2. **Database Issues**
   - Check MongoDB status
   - Review connection logs
   - Restart if necessary
   - Restore from backup if needed

3. **Security Incident**
   - Isolate affected systems
   - Review access logs
   - Update credentials
   - Notify users if necessary

## Conclusion

This deployment guide covers all aspects of deploying the RShub application. For additional support:

- **Documentation**: Check the `/docs` directory
- **Issues**: Report on GitHub
- **Support**: Contact support@rshub.com
- **Community**: Join our Discord server

Remember to always test deployments in a staging environment before production deployment.