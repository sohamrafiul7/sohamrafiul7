# RShub Database Schema

This document describes the complete database schema for the RShub application, including both Firebase Firestore and MongoDB schemas.

## Table of Contents

1. [Firestore Schema](#firestore-schema)
2. [MongoDB Schema](#mongodb-schema)
3. [Collection Relationships](#collection-relationships)
4. [Indexes](#indexes)
5. [Data Migration](#data-migration)

## Firestore Schema

### Users Collection

```javascript
{
  uid: "user_unique_id",
  phone: "+8801234567890",
  email: "user@example.com",
  name: "John Doe",
  profileImage: "https://firebasestorage.googleapis.com/...",
  bio: "Software developer and tech enthusiast",
  onlineStatus: true,
  lastSeen: Timestamp,
  walletBalance: 125.50,
  totalEarning: 345.75,
  todayEarning: 15.25,
  pendingBalance: 0.0,
  deviceId: "device_unique_id",
  isActive: true,
  isPremium: false,
  createdAt: Timestamp,
  updatedAt: Timestamp,
  lastLogin: Timestamp,
  
  // Ad settings
  adSettings: {
    groupAdsEnabled: true,
    chatAdsEnabled: false,
    groupAdFrequency: 10,
    chatAdFrequency: 20,
    autoPlayAds: true,
    adSoundEnabled: false
  },
  
  // Privacy settings
  privacySettings: {
    showOnlineStatus: true,
    showLastSeen: true,
    showProfileImage: true,
    allowDirectMessages: true,
    allowGroupInvites: true
  },
  
  // Notification settings
  notificationSettings: {
    pushNotifications: true,
    messageNotifications: true,
    groupNotifications: true,
    earningNotifications: true,
    soundEnabled: true,
    vibrationEnabled: true
  },
  
  // Lists
  blockedUsers: ["user_id_1", "user_id_2"],
  reportedBy: ["user_id_3"],
  
  // Referral system
  referralCode: "ABC123",
  referredBy: "referrer_user_id",
  referralCount: 5,
  referralEarnings: 25.00,
  
  // Statistics
  stats: {
    messagesSent: 1250,
    messagesReceived: 890,
    groupsJoined: 15,
    groupsCreated: 3,
    filesShared: 45,
    adsViewed: 234,
    lastAdView: Timestamp
  },
  
  // Security
  loginAttempts: 0,
  lockUntil: null,
  
  // Metadata
  deviceInfo: {
    platform: "android",
    version: "12.0",
    model: "Samsung Galaxy S21"
  },
  ipAddress: "192.168.1.1",
  location: {
    country: "Bangladesh",
    city: "Dhaka",
    coordinates: [90.4125, 23.8103]
  }
}
```

### Chats Collection

```javascript
{
  chatId: "chat_unique_id",
  type: "individual", // "individual" or "group"
  participants: ["user_id_1", "user_id_2"],
  
  // Last message info
  lastMessage: {
    messageId: "message_id",
    senderId: "user_id",
    content: "Hello, how are you?",
    type: "text",
    timestamp: Timestamp
  },
  lastMessageTime: Timestamp,
  
  // Unread counts per user
  unreadCount: {
    "user_id_1": 0,
    "user_id_2": 3
  },
  
  // Typing indicators
  typingUsers: ["user_id_1"],
  
  // Group specific fields
  metadata: {
    name: "Tech Enthusiasts",
    description: "A group for tech discussions",
    groupImage: "https://...",
    createdBy: "user_id",
    createdAt: Timestamp,
    isPublic: false,
    inviteLink: "https://rshub.com/invite/abc123",
    memberLimit: 1000,
    admins: ["user_id_1", "user_id_2"],
    moderators: ["user_id_3"]
  },
  
  // Ad settings per user
  adSettings: {
    "user_id_1": {
      adsEnabled: true,
      adFrequency: 10
    },
    "user_id_2": {
      adsEnabled: false,
      adFrequency: 20
    }
  },
  
  // Group settings
  settings: {
    onlyAdminsCanSendMessages: false,
    onlyAdminsCanInvite: true,
    autoDeleteMessages: false,
    messageRetentionDays: 365,
    allowFileSharing: true,
    maxFileSize: 100, // MB
    allowedFileTypes: ["image", "video", "audio", "document"]
  }
}
```

### Messages Subcollection

```javascript
// Path: chats/{chatId}/messages/{messageId}
{
  messageId: "message_unique_id",
  chatId: "chat_id",
  senderId: "user_id",
  content: "Hello, how are you doing?",
  type: "text", // "text", "image", "video", "audio", "document", "sticker"
  timestamp: Timestamp,
  isEdited: false,
  editedAt: null,
  isDeleted: false,
  deletedAt: null,
  
  // Message status
  seenBy: ["user_id_1", "user_id_2"],
  deliveredTo: ["user_id_1", "user_id_2"],
  
  // Reply functionality
  replyTo: "original_message_id",
  
  // Media metadata
  metadata: {
    fileName: "document.pdf",
    fileSize: "2.5 MB",
    fileUrl: "https://firebasestorage.googleapis.com/...",
    thumbnailUrl: "https://firebasestorage.googleapis.com/...",
    duration: 120, // seconds (for audio/video)
    width: 1920, // pixels (for images/video)
    height: 1080, // pixels (for images/video)
    mimeType: "image/jpeg",
    caption: "Check out this document"
  },
  
  // Ad data
  adData: {
    isAdMessage: false,
    adType: "interstitial",
    adRevenue: 0.001,
    adId: "ad_unique_id"
  },
  
  // Reactions
  reactions: {
    "❤️": ["user_id_1", "user_id_2"],
    "👍": ["user_id_3"]
  }
}
```

### Transactions Collection

```javascript
{
  transactionId: "transaction_unique_id",
  userId: "user_id",
  type: "earning", // "earning", "withdrawal", "referral", "bonus"
  amount: 0.50,
  currency: "USD",
  source: "group_ad", // "group_ad", "chat_ad", "file_download_ad", "daily_reward", "referral", "withdrawal"
  description: "Earning from group ad view",
  status: "completed", // "pending", "completed", "failed", "cancelled"
  timestamp: Timestamp,
  updatedAt: Timestamp,
  
  // Source details
  metadata: {
    adType: "interstitial",
    chatId: "chat_id",
    groupId: "group_id",
    messageId: "message_id",
    fileId: "file_id",
    referralUserId: "referrer_user_id",
    withdrawalId: "withdrawal_id"
  },
  
  // Earning calculation details
  earningDetails: {
    grossAmount: 0.50,
    platformFee: 0.15,
    netAmount: 0.35,
    revenueShare: 0.70 // 70% to user, 30% to platform
  }
}
```

### Withdrawals Collection

```javascript
{
  withdrawalId: "withdrawal_unique_id",
  userId: "user_id",
  amount: 100.00,
  currency: "USD",
  
  // Payment details
  paymentMethod: "bKash", // "bKash", "Nagad", "Rocket", "Bank Transfer"
  accountNumber: "+8801234567890",
  accountName: "John Doe",
  bankName: "",
  branchName: "",
  routingNumber: "",
  
  // Status tracking
  status: "pending", // "pending", "approved", "processing", "completed", "failed", "rejected"
  requestedAt: Timestamp,
  processedAt: null,
  completedAt: null,
  
  // Admin handling
  processedBy: "admin_user_id",
  approvedBy: "admin_user_id",
  rejectionReason: "",
  
  // Transaction details
  transactionId: "transaction_id",
  transactionReference: "TXN123456",
  
  // Fees
  fees: {
    platformFee: 2.00,
    paymentGatewayFee: 1.50,
    totalFees: 3.50,
    netAmount: 96.50
  },
  
  // Metadata
  metadata: {
    ipAddress: "192.168.1.1",
    userAgent: "Mozilla/5.0...",
    location: {
      country: "Bangladesh",
      city: "Dhaka"
    }
  }
}
```

### Daily Earnings Collection

```javascript
{
  id: "user_id-2024-01-15",
  userId: "user_id",
  date: "2024-01-15",
  amount: 15.25,
  updatedAt: Timestamp,
  
  // Breakdown by source
  breakdown: {
    groupAds: 8.50,
    chatAds: 3.25,
    fileDownloads: 2.50,
    dailyRewards: 1.00
  }
}
```

### Groups Collection (Extended)

```javascript
{
  groupId: "group_unique_id",
  
  // Basic info
  name: "Tech Enthusiasts",
  description: "A community for technology enthusiasts",
  groupImage: "https://...",
  
  // Membership
  members: ["user_id_1", "user_id_2", "user_id_3"],
  memberCount: 156,
  maxMembers: 1000,
  
  // Management
  createdBy: "user_id",
  admins: ["user_id_1", "user_id_2"],
  moderators: ["user_id_3"],
  
  // Settings
  isPublic: false,
  inviteOnly: true,
  joinRequests: ["user_id_4", "user_id_5"],
  bannedUsers: ["user_id_6"],
  
  // Ad revenue settings
  adRevenueEnabled: true,
  revenueShare: 0.70, // 70% to group owner, 30% to platform
  adFrequency: 10, // Show ad every 10 messages
  totalAdRevenue: 1250.50,
  
  // Statistics
  stats: {
    messagesCount: 5432,
    filesShared: 234,
    membersJoined: 189,
    membersLeft: 33
  },
  
  // Timestamps
  createdAt: Timestamp,
  updatedAt: Timestamp
}
```

### Admin Notifications Collection

```javascript
{
  notificationId: "notification_unique_id",
  type: "withdrawal_request", // "withdrawal_request", "user_report", "system_alert"
  
  // Content
  title: "New Withdrawal Request",
  message: "User John Doe has requested a withdrawal of $100",
  priority: "high", // "low", "medium", "high"
  
  // Related data
  relatedUserId: "user_id",
  relatedWithdrawalId: "withdrawal_id",
  relatedReportId: "report_id",
  
  // Status
  isRead: false,
  readBy: [],
  
  // Actions
  actions: ["approve", "reject", "review"],
  
  // Timestamps
  createdAt: Timestamp,
  updatedAt: Timestamp
}
```

### Reports Collection

```javascript
{
  reportId: "report_unique_id",
  
  // Reporter information
  reporterId: "reporter_user_id",
  reporterReason: "This user is sending spam messages",
  
  // Reported entity
  reportedType: "user", // "user", "group", "message"
  reportedUserId: "reported_user_id",
  reportedGroupId: "reported_group_id",
  reportedMessageId: "reported_message_id",
  
  // Report details
  category: "spam", // "spam", "harassment", "inappropriate_content", "scam", "other"
  description: "Detailed description of the issue",
  evidence: ["message_id_1", "message_id_2"],
  screenshots: ["https://storage.url/screenshot1.jpg"],
  
  // Status
  status: "pending", // "pending", "under_review", "resolved", "dismissed"
  priority: "medium", // "low", "medium", "high", "urgent"
  
  // Admin handling
  assignedTo: "admin_user_id",
  resolution: "User warned and messages deleted",
  actionTaken: "warning", // "warning", "temporary_ban", "permanent_ban", "content_removed"
  
  // Timestamps
  createdAt: Timestamp,
  updatedAt: Timestamp,
  resolvedAt: null
}
```

## MongoDB Schema

### User Model (MongoDB)

```javascript
const userSchema = new mongoose.Schema({
  // Basic information
  phone: { type: String, required: true, unique: true },
  email: { type: String, unique: true, sparse: true },
  name: { type: String, required: true },
  profileImage: { type: String, default: '' },
  bio: { type: String, default: '', maxlength: 500 },
  
  // Authentication
  password: { type: String, required: true, select: false },
  isVerified: { type: Boolean, default: false },
  
  // Status
  onlineStatus: { type: Boolean, default: false },
  lastSeen: { type: Date, default: Date.now },
  isActive: { type: Boolean, default: true },
  isPremium: { type: Boolean, default: false },
  
  // Wallet
  walletBalance: { type: Number, default: 0, min: 0 },
  totalEarning: { type: Number, default: 0, min: 0 },
  todayEarning: { type: Number, default: 0, min: 0 },
  pendingBalance: { type: Number, default: 0, min: 0 },
  
  // Settings
  adSettings: {
    groupAdsEnabled: { type: Boolean, default: false },
    chatAdsEnabled: { type: Boolean, default: false },
    groupAdFrequency: { type: Number, default: 10 },
    chatAdFrequency: { type: Number, default: 20 }
  },
  
  // Lists
  blockedUsers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  
  // Statistics
  stats: {
    messagesSent: { type: Number, default: 0 },
    messagesReceived: { type: Number, default: 0 },
    groupsJoined: { type: Number, default: 0 },
    groupsCreated: { type: Number, default: 0 },
    filesShared: { type: Number, default: 0 },
    adsViewed: { type: Number, default: 0 }
  }
}, { timestamps: true });
```

### Chat Model (MongoDB)

```javascript
const chatSchema = new mongoose.Schema({
  type: { type: String, enum: ['individual', 'group'], required: true },
  participants: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  
  lastMessage: {
    senderId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    content: String,
    type: { type: String, default: 'text' },
    timestamp: { type: Date, default: Date.now }
  },
  
  // Group specific fields
  name: String,
  description: String,
  groupImage: String,
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  admins: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  isPublic: { type: Boolean, default: false },
  memberLimit: { type: Number, default: 1000 }
}, { timestamps: true });
```

### Message Model (MongoDB)

```javascript
const messageSchema = new mongoose.Schema({
  chatId: { type: mongoose.Schema.Types.ObjectId, ref: 'Chat', required: true },
  senderId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  content: { type: String, required: true },
  type: { type: String, enum: ['text', 'image', 'video', 'audio', 'document', 'sticker'], default: 'text' },
  
  isEdited: { type: Boolean, default: false },
  isDeleted: { type: Boolean, default: false },
  
  seenBy: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  deliveredTo: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  
  replyTo: { type: mongoose.Schema.Types.ObjectId, ref: 'Message' },
  
  metadata: {
    fileName: String,
    fileSize: String,
    fileUrl: String,
    thumbnailUrl: String,
    duration: Number,
    width: Number,
    height: Number
  },
  
  adData: {
    isAdMessage: { type: Boolean, default: false },
    adType: String,
    adRevenue: Number
  }
}, { timestamps: true });
```

## Collection Relationships

```
Users
├── Chats (participants array)
│   ├── Messages (senderId reference)
│   └── Groups (createdBy, admins, members)
├── Transactions (userId reference)
├── Withdrawals (userId reference)
├── Reports (reporterId, reportedUserId)
└── DailyEarnings (userId reference)
```

## Indexes

### Firestore Indexes

**Single Field Indexes (automatic):**
- users.phone
- users.email
- users.onlineStatus
- users.createdAt
- chats.participants
- messages.timestamp
- transactions.userId
- transactions.timestamp

**Composite Indexes (manual):**
```
Collection: chats
Fields: participants (Array), lastMessageTime (Descending)

Collection: messages
Fields: chatId (Ascending), timestamp (Descending)

Collection: transactions
Fields: userId (Ascending), timestamp (Descending)

Collection: transactions
Fields: userId (Ascending), type (Ascending), status (Ascending)

Collection: withdrawals
Fields: userId (Ascending), status (Ascending), requestedAt (Descending)
```

### MongoDB Indexes

```javascript
// User indexes
userSchema.index({ phone: 1 });
userSchema.index({ email: 1 });
userSchema.index({ onlineStatus: 1, lastSeen: -1 });
userSchema.index({ createdAt: -1 });
userSchema.index({ totalEarning: -1 });

// Chat indexes
chatSchema.index({ participants: 1 });
chatSchema.index({ type: 1, 'metadata.name': 1 });
chatSchema.index({ 'metadata.createdBy': 1 });

// Message indexes
messageSchema.index({ chatId: 1, timestamp: -1 });
messageSchema.index({ senderId: 1, timestamp: -1 });
messageSchema.index({ 'adData.isAdMessage': 1 });

// Transaction indexes
transactionSchema.index({ userId: 1, timestamp: -1 });
transactionSchema.index({ type: 1, status: 1 });
transactionSchema.index({ source: 1, timestamp: -1 });
```

## Data Migration

### From Firebase to MongoDB

```javascript
// Example migration script
const migrateUsers = async () => {
  const firebaseUsers = await firebaseAdmin.firestore().collection('users').get();
  
  for (const doc of firebaseUsers.docs) {
    const userData = doc.data();
    
    const mongoUser = new User({
      _id: doc.id,
      phone: userData.phone,
      email: userData.email,
      name: userData.name,
      profileImage: userData.profileImage,
      bio: userData.bio,
      onlineStatus: userData.onlineStatus,
      walletBalance: userData.walletBalance || 0,
      totalEarning: userData.totalEarning || 0,
      isActive: userData.isActive !== false,
      createdAt: userData.createdAt?.toDate() || new Date(),
      updatedAt: userData.updatedAt?.toDate() || new Date()
    });
    
    await mongoUser.save();
  }
};
```

### From MongoDB to Firebase

```javascript
const migrateToFirebase = async () => {
  const users = await User.find({});
  
  for (const user of users) {
    await firebaseAdmin.firestore()
      .collection('users')
      .doc(user._id.toString())
      .set({
        phone: user.phone,
        email: user.email,
        name: user.name,
        profileImage: user.profileImage,
        bio: user.bio,
        onlineStatus: user.onlineStatus,
        walletBalance: user.walletBalance,
        totalEarning: user.totalEarning,
        isActive: user.isActive,
        createdAt: admin.firestore.Timestamp.fromDate(user.createdAt),
        updatedAt: admin.firestore.Timestamp.fromDate(user.updatedAt)
      });
  }
};
```

## Security Rules

### Firestore Security Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Users collection
    match /users/{userId} {
      allow read: if request.auth != null && 
        (request.auth.uid == userId || 
         !request.resource.data.blockedUsers.hasAny([request.auth.uid]));
      allow update: if request.auth != null && 
        request.auth.uid == userId;
      allow create: if request.auth != null;
    }
    
    // Chats collection
    match /chats/{chatId} {
      allow read: if request.auth != null && 
        request.resource.data.participants.hasAny([request.auth.uid]);
      allow update: if request.auth != null && 
        request.resource.data.participants.hasAny([request.auth.uid]);
      allow create: if request.auth != null;
    }
    
    // Messages subcollection
    match /chats/{chatId}/messages/{messageId} {
      allow read: if request.auth != null && 
        get(/databases/$(database)/documents/chats/$(chatId)).data.participants.hasAny([request.auth.uid]);
      allow create: if request.auth != null && 
        request.auth.uid == request.resource.data.senderId;
      allow update: if request.auth != null && 
        request.auth.uid == resource.data.senderId;
    }
    
    // Transactions collection
    match /transactions/{transactionId} {
      allow read: if request.auth != null && 
        request.resource.data.userId == request.auth.uid;
      allow create: if request.auth != null;
    }
    
    // Withdrawals collection
    match /withdrawals/{withdrawalId} {
      allow read: if request.auth != null && 
        request.resource.data.userId == request.auth.uid;
      allow create: if request.auth != null && 
        request.resource.data.userId == request.auth.uid;
    }
  }
}
```

This schema provides a comprehensive structure for the RShub application, supporting all features including real-time messaging, ad-based earnings, wallet management, and admin functionality. The schema is designed to be scalable and efficient for both Firebase Firestore and MongoDB implementations.